# Getting started with Play (Scala)

This project demonstrate how to create a simple CRUD application with Play.