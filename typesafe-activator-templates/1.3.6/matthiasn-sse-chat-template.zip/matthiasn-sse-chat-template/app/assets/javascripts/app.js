'use strict';

/** app level module which depends on services and controllers */
angular.module('sseChat', ['sseChat.services', 'sseChat.controllers']);