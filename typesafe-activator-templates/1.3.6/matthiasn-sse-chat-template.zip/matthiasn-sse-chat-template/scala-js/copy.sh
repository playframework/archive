#!/bin/sh

cp target/scala-2.10/example-intdeps.js ../public/scala-js/
cp target/scala-2.10/example-extdeps.js ../public/scala-js/
cp target/scala-2.10/example-extdeps.js.map ../public/scala-js/
cp target/scala-2.10/example.js ../public/scala-js/
cp target/scala-2.10/example.js.map ../public/scala-js/

cp target/scala-2.10/example-opt.js ../public/scala-js-opt/
