Files on this folder is not meant to be compiled. 

They are here only to be used as examples on the tutorial.