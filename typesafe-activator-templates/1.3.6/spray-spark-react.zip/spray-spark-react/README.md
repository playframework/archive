# activator-spray-spark-react
An activator template demonstrating Spray, Akka, Spark, and React

# run
```
activator run
```

this application uses sbt-revolver, which allows you to hot-deploy spray using

```
activator> ~ re-start
```
