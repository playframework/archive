package com.example

trait Foo {

  def hello(name: String): String = s"hello, $name"

}
