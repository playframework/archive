CREATE TABLE "users" (
  "id"       BIGSERIAL PRIMARY KEY,
  "username" VARCHAR NOT NULL,
  "password" VARCHAR NOT NULL
);