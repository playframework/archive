 
/*
 * Generated via the com.flca generator
 */
	
package flca.demo.srv.mock
	
import flca.demo.dto.TstDto
import flca.demo.entity.Tsta
import flca.demo.srv.TstService
object TstServiceMock extends TstService {
 
	def helloWorld() : String  = {
		//TODO add your implementation
		null
	}
	def pingMe(aMessage1:String,  aMessage2:String) : String  = {
		//TODO add your implementation
		null
	}
	def saveTestA(aValue:Tsta) : Tsta  = {
		//TODO add your implementation
		null
	}
	def searchTestA(aName:String) : List[Tsta]  = {
		//TODO add your implementation
		null
	}
	def getDto(aValue:TstDto) : TstDto  = {
		//TODO add your implementation
		null
	}
	def ping(aMessage:String) : String  = {
		//TODO add your implementation
		null
	}
	def doSomething() : Unit  = {
		//TODO add your implementation
		
	}
}
