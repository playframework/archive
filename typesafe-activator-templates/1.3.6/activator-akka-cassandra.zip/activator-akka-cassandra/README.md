activator-akka-cassandra
========================

Activator template showing Cassandra in Akka
