package object core {

  private[core] object Keyspaces {
    val akkaCassandra = "akkacassandra"
  }

  private[core] object ColumnFamilies {
    val tweets = "tweets"
  }

}
