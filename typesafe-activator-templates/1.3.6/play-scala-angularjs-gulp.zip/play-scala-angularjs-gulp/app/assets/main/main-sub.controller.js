angular.module('app').controller('main-sub.controller', function ($scope) {

  console.log('Hello main-sub.controller!');

});
