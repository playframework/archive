angular.module('app').controller('main-index.controller', function($scope) {

  console.log('Hello main-index.controller!');

});
