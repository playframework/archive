activator-akka-spray
====================

Basic Akka / Spray template showing REST API built around Akka actors.
