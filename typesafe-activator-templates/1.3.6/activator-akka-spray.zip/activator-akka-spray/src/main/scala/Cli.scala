import core.{BootedCore, CoreActors}

object Cli extends App with BootedCore with CoreActors
