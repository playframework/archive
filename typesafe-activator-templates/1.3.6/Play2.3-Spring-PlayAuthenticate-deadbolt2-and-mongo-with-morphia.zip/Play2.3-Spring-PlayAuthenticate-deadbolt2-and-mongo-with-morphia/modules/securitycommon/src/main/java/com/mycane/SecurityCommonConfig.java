package com.mycane;

import org.springframework.context.annotation.Configuration;

/**
 * Created by esfandiaramirrahimi on 2015-05-06.
 */
@Configuration
public class SecurityCommonConfig {
}
