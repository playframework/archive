package com.mycane.notification.vo;

/**
 * Created by esfandiaramirrahimi on 2015-05-03.
 */
public interface IMessageContent {
    public String getText();

    public String getHtml();
}
