package com.mycane.notification.type;

/**
 * Created by esfandiaramirrahimi on 2015-05-03.
 */
public enum NotificationType {
    INVITATION, VERIFICATION, PASSWORD_RESET
}
