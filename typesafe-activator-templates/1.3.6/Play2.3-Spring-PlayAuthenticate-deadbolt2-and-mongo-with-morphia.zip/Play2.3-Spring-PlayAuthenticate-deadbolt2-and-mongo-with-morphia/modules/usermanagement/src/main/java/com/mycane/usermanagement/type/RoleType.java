package com.mycane.usermanagement.type;

/**
 * Created by esfandiaramirrahimi on 2015-05-08.
 */
public class RoleType {
    public static final String USER = "user";
}
