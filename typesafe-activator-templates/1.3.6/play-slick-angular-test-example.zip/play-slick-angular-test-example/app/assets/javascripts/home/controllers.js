/**
 * Home controllers.
 */
define([], function() {
	'use strict';

	/** Controls the footer */
	var FooterCtrl = function(/* $scope */) {
	};
	// FooterCtrl.$inject = ['$scope'];

	return {
		FooterCtrl : FooterCtrl
	};

});
