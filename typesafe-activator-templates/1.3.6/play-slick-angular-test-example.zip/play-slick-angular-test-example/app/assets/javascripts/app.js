define(['angular', 'home', 'report'], function(angular) {
    'use strict';

    return angular.module('app', ['home', 'report']);
});
