React.render(
  <em>I was generated from /app/assets/javascripts/component.jsx</em>,
  document.getElementById('example')
);
