This is your new IBM Connections Add-on
=======================================

1. To build the add-on, run spokes-sdk build.

2. To deploy the add-on to IBM BlueMix, run spokes-deploy.
