/**
 * This package contains messages that are sent between Akka actors.
 */ 
package com.vaadin.vaadininmuija.akka.messages;
