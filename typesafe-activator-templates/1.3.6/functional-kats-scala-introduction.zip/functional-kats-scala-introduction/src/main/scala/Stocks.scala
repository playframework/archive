import scala.xml._
import com.ning.http.client._

object Stocks {

  def getResponse(url: String): Option[String] = {
    val client = new AsyncHttpClient()
    val response = client.prepareGet(url).execute().get()
    val body = response.getResponseBody
    client.close()
    Some(body)
  }

  def getStockQuote(stock: String): Option[BigDecimal] = {
    val url = "http://www.webservicex.net/stockquote.asmx/GetQuote?symbol=" + stock

    val msg = getResponse(url)

    val xmlDoc = XML.loadString(msg.get)
    val innerStr = XML.loadString(xmlDoc.text)

    val node = innerStr \\ "Last"

    if (node.isEmpty)
      None
    else
      Some(BigDecimal(node.text))
  }

  def main(args: Array[String]): Unit = {
    val myPortfolio = ???
    val myPortfolioValue = ???

    println("Portfolio value is " + myPortfolioValue)
  }
}
