inno-playground
===

Empty project with a bunch of the libraries we use set up and some testing shiz as well.
