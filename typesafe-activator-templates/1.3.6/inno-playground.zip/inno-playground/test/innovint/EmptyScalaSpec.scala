package innovint

import org.scalacheck._
import Prop._

class EmptyScalaSpec extends Properties("Empty Spec"){
  property("num plus 0 is same num") = forAll { i :Int =>
    (i + 0) ?= i
  }
}