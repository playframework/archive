package innovint

import org.scalatest._

/**
 * This test shows the dangers in using vals and objects defined with abstract members in traits because
 * it makes the order of import which defines the order of initialization supremely important.
 *
 * An easy solution for this is to change the vals to lazy vals or defs but sometimes this cannot be done. Sometimes
 * macros are using abstract members to generate code, for example Play json macros. If this is the case make sure
 * you get order of import correct.
 */
class OrderOfInitializationTest extends WordSpec with MustMatchers {

  case class Stuff( stuff :Int ) {
    def plus( otherStuff :Stuff ) = Stuff( stuff + otherStuff.stuff )
  }

  trait WithAbstract {
    def stuff :Stuff
    val doubleStuff = stuff plus stuff
  }

  trait DoubleDoubleStuff { self :WithAbstract =>
    val doubleDoubleStuff = doubleStuff plus stuff
  }

  "order of initialization" should {
    case class AbsDouble(stuff :Stuff) extends WithAbstract with DoubleDoubleStuff

    case class DoubleAbs(stuff: Stuff) extends DoubleDoubleStuff with WithAbstract

    "matter abs double" in {
      AbsDouble(Stuff(10)).doubleStuff must be(Stuff(20))
      AbsDouble(Stuff(10)).doubleDoubleStuff must be(Stuff(30))
    }

    "matter doubs abs" in {
      intercept[NullPointerException] {
        DoubleAbs(Stuff(10)).doubleStuff
      }

      intercept[NullPointerException] {
        DoubleAbs(Stuff(10)).doubleDoubleStuff
      }
    }
  }
}
