activator-typeclass-tips
========================

Some tricks and tips with Scala typeclasses, as an Activator Template
