akka-eventuate-scala
====================

[Activator](https://www.typesafe.com/community/core-tools/activator-and-sbt) tutorial-template for 
[eventuate](https://github.com/RBMHTechnology/eventuate).
[Submitted](https://www.typesafe.com/activator/template/akka-eventuate-scala) to activator-catalog
so you can open it simply through the activator ui (filter by "eventuate").