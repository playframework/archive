# spray-seed
Spray.io initial project (for activator)
