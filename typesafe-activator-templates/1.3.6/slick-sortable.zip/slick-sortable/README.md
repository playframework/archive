This is a template for [Typesafe Activator](http://typesafe.com/platform/getstarted). See [the tutorial](tutorial/index.html) for a description.
