package com.zenaptix.reactive

import akka.actor.ActorSystem
import akka.stream.ActorFlowMaterializer
import akka.stream.scaladsl.Sink
import com.typesafe.config.ConfigFactory
import com.typesafe.scalalogging.LazyLogging

/**
 * Created by ian on 2015/06/05.
 *
 */

object ReactiveSubscriber extends App with LazyLogging {
  implicit val system = ActorSystem("subscriber")
  implicit val materializer = ActorFlowMaterializer()
  def rxZmq = RxZMQExtension(system)
  val conf = ConfigFactory.load()
  val connection = conf.getString("zeromq.host") + ":" + conf.getInt("zeromq.port")
  rxZmq.subSource(connection).map(m => logger.debug(s"SINK <- ${m.head.decodeString("UTF8")}")).runWith(Sink.ignore)
  system.awaitTermination()
}
