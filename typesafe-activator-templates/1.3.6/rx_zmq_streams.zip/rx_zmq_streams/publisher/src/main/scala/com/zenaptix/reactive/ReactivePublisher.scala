package com.zenaptix.reactive

import java.io.File

import akka.actor.ActorSystem
import akka.stream.ActorFlowMaterializer
import akka.stream.io.SynchronousFileSource
import com.typesafe.config.ConfigFactory
import com.typesafe.scalalogging.LazyLogging


/**
 * Created by ian on 2015/06/05.
 *
 */

object ReactivePublisher extends App with LazyLogging {
  implicit val system = ActorSystem("publisher")
  implicit val materializer = ActorFlowMaterializer()
  lazy val log = system.log
  def rxZmq = RxZMQExtension(system)
  val conf = ConfigFactory.load()
  val sourcePath = conf.getString("gateway.source_path")
  val file = new File(sourcePath)
  SynchronousFileSource(file,13).map(b => {
    logger.debug(s"[SOURCE] -> ${b.decodeString("UTF8")}")
    Message(b)
  }).runWith(rxZmq.pubSink())
  system.awaitTermination()
}