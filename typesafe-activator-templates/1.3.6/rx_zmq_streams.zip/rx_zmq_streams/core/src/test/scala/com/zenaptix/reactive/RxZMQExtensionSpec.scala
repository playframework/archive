package com.zenaptix.reactive

import java.io.File

import akka.actor.ActorSystem
import akka.stream.ActorFlowMaterializer
import akka.stream.io.SynchronousFileSource
import akka.stream.scaladsl.Sink
import akka.testkit.TestKit
import akka.util.Timeout
import com.typesafe.config.{Config, ConfigFactory}
import com.typesafe.scalalogging.LazyLogging
import org.scalatest.{FlatSpecLike, Matchers}
import scala.concurrent.duration._


/**
 * Created by Ian de Beer
 * on 2015/04/15.
 * for zenAptix (Pty) Ltd
 */
class RxZMQExtensionSpec extends TestKit(ActorSystem("RxZMQExtensionSpec", RxZMQConfig.configs)) with FlatSpecLike with Matchers with LazyLogging {

  implicit val timeout: Timeout = Timeout(5 seconds)
  implicit val materializer = ActorFlowMaterializer()
  val conf = RxZMQConfig.configs

  def rxZmq = RxZMQExtension(system)

  "A RxZMQExtension " should "provide a pubSink that will transmit its data from an Akka Stream onto zeroMQ" in {
  }
  it should "provide a subSource that will receive data over zeroMQ and stream it out to a subsequent Akka Stream" in {
  }

  it should "transmit the data and allow for a push back on the zeroMQ transmission" in {
    //create a test source for the Akka Stream from a file
    val sourcePath = conf.getString("gateway.source_path")
    val file = new File(sourcePath)

    SynchronousFileSource(file,13).map(b => {
      logger.debug(s"[SOURCE] -> ${b.decodeString("UTF8")}")
      Message(b)
    }).runWith(rxZmq.pubSink())

    var i = 0
    val subSource = rxZmq.subSource("0.0.0.0:5556")
    subSource.map(
      m => {
        i += 1
        logger.debug(s"[SINK]] <- ${m.head.utf8String}")
      }
    ).runWith(Sink.ignore)
    Thread.sleep(5000)
    i  shouldBe 50
  }
}

object RxZMQConfig {
  val confS = """
                zeromq {
                |  host = "0.0.0.0"
                |  port = 5556
                |  block_size = 10
                |  block_timeout_seconds = 5
                |}
                |gateway {
                |  source_path = "data/test.txt"
                |}
                |rx_zmq_stream {
                |  retry_count = 10
                |    # in milliseconds
                |  retry_delay = 1000
                |      # in seconds
                |  time_out_period = 5
                |  block_size = 10
                |  highwater_mark = 20
                |  lowwater_mark = 10
                |}
                |akka {
                |  loggers = ["akka.event.slf4j.Slf4jLogger"]
                |  logging-filter = "akka.event.slf4j.Slf4jLoggingFilter"
                |  log-dead-letters = false
                |  akka.log-dead-letters-during-shutdown = false
                |  loglevel = "DEBUG"
                |}
              """.stripMargin
  val configs = ConfigFactory.parseString(confS)

  def config(configs: String*): Config = configs.foldLeft(ConfigFactory.empty)((r, c) ⇒ r.withFallback(ConfigFactory.parseString(c)))
}





