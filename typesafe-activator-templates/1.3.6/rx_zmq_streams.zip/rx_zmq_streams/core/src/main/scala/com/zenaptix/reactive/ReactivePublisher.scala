package com.zenaptix.reactive

/**
 * Created by ian on 2015/03/16.
 *
 */


import akka.actor._
import com.typesafe.config.ConfigFactory
import org.reactivestreams.{Publisher, Subscription, Subscriber}
import akka.stream.actor.{MaxInFlightRequestStrategy, RequestStrategy, ActorSubscriber}
import akka.util.ByteString
import org.zeromq.ZMQ
import org.json4s.ShortTypeHints
import org.json4s.native.JsonMethods._
import org.json4s.native.Serialization
import org.json4s.native.Serialization._
import scala.collection.mutable
import com.typesafe.scalalogging.LazyLogging


object ZMQPublisher {
  val conf = ConfigFactory.load()
  val host = conf.getString("zeromq.host")
  val port = conf.getInt("zeromq.port")

  def props() = Props(new ZMQPublisher(host, port))
}

class ZMQPublisher(host: String, port: Int) extends ActorSubscriber with ActorLogging with Publisher[Long] {
  val MaxQueueSize = 10000
  val MaxRetries = 10

  var queue: mutable.Queue[Message] = new mutable.Queue[Message]()
  val connection = s"tcp://0.0.0.0:$port"
  val controlChannel = ZMQControllChannelServer(self, connection)
  val pubChannel = context.actorOf(ZMQPublisherProxy.props(), name = s"_ZMQPublisherProxy_$port")
  var previousSent = 0
  var isComplete = false
  var retries = 0
  var batch: Option[mutable.Queue[Message]] = None

  override def preStart() = {
    log.debug(s"Starting a new ØMQ Publisher: ${context.self.path}")
    super.preStart()
  }

  override def receive: Receive = {
    case n: Next =>
      if (queue.isEmpty && isComplete) {
        controlChannel.onComplete()
      }
      else {
        queue = queue.drop(previousSent)
        if (n.count >= queue.size) {
          batch = Some(queue)
          controlChannel.onNext(batch.get.size)
          previousSent = batch.get.size
        }
        else {
          batch = Some(queue.splitAt(n.count.toInt)._1)
          controlChannel.onNext(n.count)
          previousSent = n.count.toInt
        }
      }
      if (batch.nonEmpty) {
        pubChannel ! batch.get
      }
    case e: Error =>
      retries += 1
      if (batch.isEmpty) {
        controlChannel.onError(new ZMQIrrecoverableError(OnError(recoverable = false, message = s"No data available")))
      }
      else {
        if (retries < MaxRetries) {
          controlChannel.onNext(batch.size)
          pubChannel ! batch
        }
        else {
          controlChannel.onError(new ZMQIrrecoverableError(OnError(recoverable = false, message = s"Error: Exceeds maximum retries: $MaxRetries")))
        }
      }
    case akka.stream.actor.ActorSubscriberMessage.OnNext(msg: Message) =>
      //println("received a " + msg.part.decodeString("UTF8"))
      queue.enqueue(msg)
    case akka.stream.actor.ActorSubscriberMessage.OnComplete => isComplete = true
    case a: Any =>
      log.error("received an unsolicited " + a.getClass)
  }

  override protected def requestStrategy: RequestStrategy = {
    new MaxInFlightRequestStrategy(max = MaxQueueSize) {
      override def inFlightInternally: Int = queue.size
    }
  }

  override def subscribe(subscriber: Subscriber[_ >: Long]): Unit = {
    //for now there is only 1 subscriber: ZMQControllChannelServer
  }
}


case class ZMQControllChannelServer(publisher: ActorRef, connection: String) extends Subscriber[Long] with LazyLogging {
  implicit val formats = Serialization.formats(ShortTypeHints(List(classOf[Subscribe], classOf[OnSubscribe], classOf[Next], classOf[OnNext], classOf[OnComplete], classOf[Error], classOf[OnError])))
  val zmqContext = ZMQ.context(1)
  val server = zmqContext.socket(ZMQ.REP)
  server.bind(connection)
  val log = logger
  val thread = new Thread {
    override def run() {
      while (true) {
        val m = server.recv()
        val msg = parse(ByteString(m).decodeString("UTF8")).extract[ControlMessage]
        logger.debug(s"[SERVER] <- CONTROL:  $msg")
        msg match {
          case e: Error => publisher ! e
          case s: Subscribe => onSubscribe(Subs())
          case n: Next => publisher ! n
        }
        Thread.sleep(10)
      }
    }
  }
  thread.start()

  override def onError(throwable: Throwable): Unit = {
    throwable match {
      case error: ZMQSRecoverableError => send(error.error)
      case error: ZMQIrrecoverableError => send(error.error)
      case _ => send(OnError(recoverable = false, message = throwable.getMessage))
    }
  }

  override def onSubscribe(subs: Subscription): Unit = {
    send(OnSubscribe(size = 50, port = ZMQPublisher.port + 1))
  }

  override def onComplete(): Unit = {
    send(OnComplete(complete = true))
  }

  override def onNext(l: Long): Unit = {
    send(OnNext(l))
  }

  def send(msg: ControlMessage): Unit = {
    val m = write(msg)
    logger.debug(s"[SERVER] -> CONTROL: $msg  ")
    server.send(m)
  }
}

case class Subs() extends Subscription  {
  override def cancel(): Unit = {}
  override def request(l: Long): Unit = {}
}

object ZMQPublisherProxy extends LazyLogging {
  def props(): Props = Props(new ZMQPublisherProxy())

  val conf = ConfigFactory.load()
  val port = conf.getInt("zeromq.port")
  val context = ZMQ.context(1)
  val publisher = context.socket(ZMQ.PUB)
  publisher.bind(s"tcp://*:${port + 1}")

  def send(queue: mutable.Queue[Message]) = {
    queue.dequeueAll(m => true).map(m => {
      logger.debug(s"[SERVER] -> DATA: ${m.head.decodeString("UTF8")}")
      publisher.send(m.head.toArray, 0)
    })
  }
}

class ZMQPublisherProxy() extends Actor with ActorLogging {

  import ZMQPublisherProxy._

  override def preStart() = {
    log.info(s"Starting a new ØMQ PublisherProxy : ${context.self.path}")
    super.preStart()
  }

  override def receive = {
    case messages: mutable.Queue[Message@unchecked] =>
      send(messages)
    case a: Any => log.error("controller got " + a)
  }
}
