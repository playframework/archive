package com.zenaptix.reactive


import akka.actor.SupervisorStrategy.{Escalate, Restart}
import akka.actor._

import akka.stream.actor.ActorPublisher
import akka.stream.actor.ActorPublisherMessage.{Request, Cancel}
import akka.util.Timeout
import com.typesafe.config.ConfigFactory
import org.json4s.ShortTypeHints
import org.json4s.native.JsonMethods._
import org.json4s.native.Serialization
import org.json4s.native.Serialization._
import org.reactivestreams.{Subscription, Subscriber}
import org.zeromq.ZMQ
import org.zeromq.ZMQ.{Poller, PollItem}
import scala.annotation.tailrec
import scala.collection.mutable
import scala.concurrent.{Await, Promise, Future}
import scala.concurrent.duration._
import scala.util.{Failure, Success, Try}
import akka.pattern.{AskTimeoutException, ask}
import akka.util.ByteString
import scala.collection.IndexedSeqLike
import scala.collection.mutable.ArrayBuffer


object ZMQProxyPublisher {
  def props(connection: String) = Props(new ZMQProxyPublisher(connection))

  val conf = ConfigFactory.load()
  val highwaterMark = conf.getInt("rx_zmq_stream.highwater_mark")
  val lowwaterMark = conf.getInt("rx_zmq_stream.lowwater_mark")
}

class ZMQProxyPublisher(connection: String) extends ActorPublisher[Message] with ActorLogging {

  import ZMQProxyPublisher._

  val subscriber = context.actorOf(ZMQSubscriber.props(connection), name = s"_ZMQSubscriber_$connection")

  var queue: mutable.Queue[Message] = new mutable.Queue[Message]()
  override val supervisorStrategy =
    OneForOneStrategy(maxNrOfRetries = 100, withinTimeRange = 5 minutes) {
      case _: NetworkFailureException => Restart
      case _: Exception => Escalate
    }

  override def receive = {
    case msgQueue: mutable.Queue[Message@unchecked] =>
      queue.enqueue(msgQueue: _*)
      deliverBuf()
    case Request(cnt: Long) =>
      if (queue.size > highwaterMark) {
        subscriber ! BackPressure(cnt)
      }
      else {
        if (queue.size < lowwaterMark) {
          subscriber ! BackPressure(scala.math.min(cnt * 2, highwaterMark - queue.size))
        }
      }
      deliverBuf()
    case Cancel =>
      deliverBuf()
      context.stop(self)
    case a: Any =>
      log.error("receive an unsolicited message: " + a)
  }

  @tailrec
  final def deliverBuf() {
    if (totalDemand > 0) {
      if (totalDemand <= Int.MaxValue) {
        val (use, keep) = queue.splitAt(totalDemand.toInt)
        queue = keep
        use foreach onNext
      }
      else {
        val (use, keep) = queue.splitAt(totalDemand.toInt)
        queue = keep
        use foreach onNext
        deliverBuf()
      }
    }
  }
}

object ZMQSubscriber {
  val conf = ConfigFactory.load()
  val retryCount = conf.getInt("rx_zmq_stream.retry_count")
  val retryDelay = conf.getLong("rx_zmq_stream.retry_delay")
  val timeoutPeriod = conf.getInt("rx_zmq_stream.time_out_period")

  def props(connection: String) = Props(new ZMQSubscriber(connection))
}

class ZMQSubscriber(val connection: String) extends Actor with ActorLogging with Subscriber[ControlMessage] with ZeroMQProvider {

  import ZMQSubscriber._
  import scala.concurrent.ExecutionContext.Implicits.global


  val controlChannel: ActorRef = context.actorOf(Props(new ControlChannel(connection)), name = s"_ControlChannel_$connection")
  var block = conf.getInt("rx_zmq_stream.block_size")
  var dataChannel: Option[ActorRef] = None
  implicit val formats = Serialization.formats(ShortTypeHints(List(classOf[Subscribe], classOf[OnSubscribe], classOf[Next], classOf[OnNext], classOf[OnComplete], classOf[OnError], classOf[NetworkFailure])))
  implicit val timeout = Timeout(timeoutPeriod seconds)

  override def preStart() = {
    log.info(s"Starting a new ØMQ Subscriber: ${context.self.path}")
    subscribe()(timeout.duration)
    super.preStart()
  }

  override def preRestart(cause: Throwable, msg: Option[Any]): Unit = {
    log.info(s"Restarting the ØMQ Subscriber: ${context.self.path} after $cause")
    super.preRestart(cause, msg)
  }

  def subscribe()(implicit timeout: Duration) = {
    val future = retry(RequestMsg(Message(ByteString(write(Subscribe(cancel = false))))), 0)
    val result = Try {
      Await.result(future, timeout) match {
        case controlMsg: OnSubscribe =>
          dataChannel = Some(context.actorOf(DataChannel.props(connection.split(":").head + s":${controlMsg.port}"), name = s"_DataChannel_$connection"))
          onSubscribe(Subs())
        case _ =>
          self ! new NetworkFailureException
      }
    }
    if (result.isFailure) {
      Thread.sleep(5000)
      self ! new NetworkFailureException
    }
  }

  override def receive: Receive = {
    case ex: NetworkFailureException =>
      throw ex
    case n: BackPressure =>
      block = n.count.toInt
  }

  override def onError(e: Throwable) = {
    if (e.isInstanceOf[ZMQIrrecoverableError]) {
      onComplete()
    }
    else {
      requestNext(block)(timeout.duration)
    }
  }

  override def onSubscribe(subs: Subscription) = {
    requestNext(block)(timeout.duration)
  }

  override def onComplete() = {
    log.debug(s"[CLIENT] : Subscription completed")
    context.parent ! Cancel
    Thread.sleep(5000)
    context.system.shutdown()
  }

  override def onNext(next: ControlMessage) = {
    val n = next.asInstanceOf[OnNext]
    if (n.count > 0) {
      val f = dataChannel.get ask Next(n.count)
      Await.result(f, timeout.duration) match {
        case data: mutable.Queue[Message@unchecked] => context.parent ! data
        case _ => controlChannel ! RequestMsg(Message(ByteString(write(Error("TimeOut")))))
      }
    }
    else {
      Thread.sleep(timeout.duration.toMillis)
    }
    requestNext(block)(timeout.duration)
  }

  def requestNext(block: Int)(implicit timeout: Duration): Unit = {
    val future = retry(RequestMsg(Message(ByteString(write(Next(block))))), 0)
    val result = Try {
      Await.result(future, timeout) match {
        case n: OnNext =>
          onNext(n)
        case e: OnError =>
          if (e.recoverable) {
            onError(ZMQSRecoverableError(e))
          }
          else {
            onError(ZMQIrrecoverableError(e))
          }
        case c: OnComplete =>
          onComplete()
        case _ =>
          self ! new NetworkFailureException
      }
    }
    if (result.isFailure) {
      Thread.sleep(5000)
      self ! new NetworkFailureException
    }
  }

  def retry(message: Any, attempt: Int): Future[Any] = {
    val future = controlChannel.ask(message) recover {
      case e: AskTimeoutException =>
        if (attempt <= retryCount) {
          retry(message, attempt + 1)
        }
        else {
          Future.failed(new NetworkFailure(retryCount).asInstanceOf[Throwable])
        }
    }
    future
  }
}

object ControlChannel {
  def props(connection: String): Props = Props(new ControlChannel(connection))

  val conf = ConfigFactory.load()
  val timeoutPeriod = conf.getInt("rx_zmq_stream.time_out_period")
  val retries = conf.getInt("rx_zmq_stream.retry_count")
}

class ControlChannel(connection: String) extends Actor with ActorLogging {

  import ControlChannel._
  import akka.pattern.pipe

  implicit val formats = Serialization.formats(ShortTypeHints(List(classOf[Subscribe], classOf[OnSubscribe], classOf[Next], classOf[OnNext], classOf[OnComplete], classOf[OnError], classOf[NetworkFailure])))
  implicit val timeout = Timeout(timeoutPeriod seconds)

  import scala.concurrent.ExecutionContext.Implicits.global

  val zmqContext = ZMQ.context(1)
  val requester = zmqContext.socket(ZMQ.REQ)
  requester.connect(s"tcp://$connection")

  override def receive = {
    case ex: Exception => context.parent ! ex
    case request: RequestMsg =>
      val promise = Promise[ControlMessage]()
      promise.future pipeTo sender()
      val reply = retry(request, 0)
      reply match {
        case Failure(e) => throw e
        case Success(msg) =>
          log.debug(s"[CLIENT] <- $msg")
          promise.success(msg)
      }
    case a: Any => log.error("received a bogus reply" + a)
  }

  def retry(request: RequestMsg, attempt: Int): Try[ControlMessage] = {
    log.debug(s"[CLIENT] -> ${request.msg.head.decodeString("UTF8")}")
    requester.send(request.msg.head.toArray, 0)
    val pollItems = Array(new PollItem(requester, Poller.POLLIN))
    val response = ZMQ.poll(pollItems, timeout.duration.toMillis)
    if (response == -1) {
      Failure(new PollInterruptedException())
    }
    else {
      if (pollItems(0).isReadable) {
        val reply = ByteString(requester.recv).decodeString("UTF8")
        val msg = parse(reply).extract[ControlMessage]
        Success(msg)
      }
      else if (attempt <= retries) {
        retry(request, attempt + 1)
      }
      else {
        Failure(new NetworkFailureException())
      }
    }
  }
}

object DataChannel {
  def props(connection: String): Props = Props(new DataChannel(connection: String))
}

class DataChannel(connection: String) extends Actor with ActorLogging with Subscription {

  import akka.pattern.pipe
  import scala.concurrent.ExecutionContext.Implicits.global

  val queue: mutable.Queue[Message] = new mutable.Queue[Message]()
  val conf = ConfigFactory.load()
  val retryCount = conf.getInt("rx_zmq_stream.retry_count")
  val retryDelay = conf.getLong("rx_zmq_stream.retry_delay")
  val timeoutPeriod = conf.getInt("rx_zmq_stream.time_out_period")

  implicit val formats = Serialization.formats(ShortTypeHints(List(classOf[Subscribe], classOf[OnSubscribe], classOf[Next], classOf[OnNext], classOf[Error], classOf[OnComplete], classOf[OnError])))
  implicit val timeout = Timeout(timeoutPeriod seconds)

  override def cancel() = {} // not sure where this applies

  override def request(l: Long) = {
    val promise = Promise[mutable.Queue[Message]]()
    promise.future pipeTo sender()
    val queue: mutable.Queue[Message] = new mutable.Queue[Message]()
    while (queue.size < l) {
      for (m <- receiveMessage(Vector.empty)) yield queue.enqueue(m)
    }
    promise.success(queue)
  }

  @tailrec
  final def receiveMessage(currentFrames: Vector[ByteString] = Vector.empty): Option[Message] =
    subscriber.recv(ZMQ.NOBLOCK) match {
      case null => None
      case bytes =>
        val frames = currentFrames :+ ByteString(bytes)
        if (subscriber.hasReceiveMore)
          receiveMessage(frames)
        else {
          Some(Message(frames: _*))
        }
    }

  val zmqContext = ZMQ.context(1)
  val subscriber = zmqContext.socket(ZMQ.SUB)
  subscriber.connect(s"tcp://$connection")
  subscriber.subscribe("".getBytes)

  override def receive = {
    case n: Next => request(n.count)
  }
}

object Message {
  def apply(parts: ByteString*) = new Message(parts: _*)

  def unapplySeq(message: Message) = IndexedSeq.unapplySeq(message)
}

class Message(parts: ByteString*) extends IndexedSeq[ByteString] with IndexedSeqLike[ByteString, Message] {
  private val underlying = parts.toIndexedSeq

  override def apply(idx: Int) = underlying(idx)

  override def length = underlying.length

  override def newBuilder: mutable.Builder[ByteString, Message] = ArrayBuffer.empty[ByteString].mapResult(Message.apply)
}

case class ZMQSRecoverableError(error: OnError) extends Throwable

case class ZMQIrrecoverableError(error: OnError) extends Throwable

case object TimeOut

case class RequestMsg(msg: Message)

case class ReplyMsg(msg: ControlMessage)

class NetworkFailureException extends Exception

class PollInterruptedException extends Exception
