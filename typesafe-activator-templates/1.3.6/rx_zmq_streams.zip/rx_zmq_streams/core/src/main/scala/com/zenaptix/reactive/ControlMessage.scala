package com.zenaptix.reactive


/**
 * Created by ian on 2015/03/13.
 *
 */
trait ControlMessage

case class Subscribe(cancel:Boolean = false) extends ControlMessage

case class OnSubscribe(size:Long, port:Int = 5557) extends ControlMessage

case class Next(count:Long = 1000)  extends ControlMessage

case class OnNext(count:Long = 1000)  extends ControlMessage

case class Error(message: String) extends ControlMessage

case class OnError(recoverable:Boolean = false, message:String = "Error")  extends ControlMessage

case class OnComplete(complete:Boolean = true)  extends ControlMessage

case class Complete()

case object Tick

case class BackPressure(count:Long = 1)

case class NetworkFailure(retried:Int) extends ControlMessage