package com.zenaptix.reactive

import akka.actor._
import akka.stream.scaladsl.{Source, Sink}
import com.typesafe.config.ConfigFactory

/**
 * Created by ian on 2015/04/14.
 * 
 */

/**
 * ReactiveZeroMQ Publisher Subscriber  Extension companion
 */
object RxZMQExtension extends ExtensionId[RxZMQExtension] with ExtensionIdProvider {

  val conf = ConfigFactory.load()
  def lookup() = RxZMQExtension
  override def createExtension(system: ExtendedActorSystem): RxZMQExtension = new RxZMQExtension(system)
  
}

/**
 * ReactiveZeroMQ Publisher Subscriber Extension that provides a:
 * 1. pubSink that will transmit its data from an Akka Stream onto zeroMQ
 * 2. subSource that will receive data over zeroMQ and stream it out to a subsequent Akka Stream
 * 3. the pubSink and subSource are implementing the Reactive Streams protocol and as such allows for a push back on the zeroMQ transmission
 * It uses the mDialog/scala-zeromq extension for Akka
 * @param system Actor System
 */
class RxZMQExtension (val system: ActorSystem) extends Extension  {

  /**
   * An implementation of the Reactive Stream Publisher protocol
   * that is both a zeroMQ Pub socket and a Akka Streams Sink (subscriber)
   */
  def pubSink(): Sink[Message,ActorRef] = Sink.actorSubscriber(ZMQPublisher.props())
  /**
   * An implementation of the Reactive Stream Subscriber protocol
   * that is both a zeroMQ Sub socket and a Akka Streams Source (publisher
   */
  def subSource(connection:String): Source[Message,ActorRef] = Source.actorPublisher(ZMQProxyPublisher.props(connection))
}

trait ZeroMQProvider {
  val connection: String
  val controlChannel:ActorRef
}

