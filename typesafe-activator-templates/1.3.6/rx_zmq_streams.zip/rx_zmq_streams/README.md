ZeroMQ/Akka streams activator template
=======================================

Using ZeroMQ Pub/Subl socket as the transport for Reactive Streams as implemented with Akka Streams.

Akka Streams is an implementation of [Reactive Streams](http://www.reactive-streams.org/)
zeroMQ is a Socket Library disguised as a concurrency framework. "Sockets on steroids"
This application provides a heuristic implementation of Reactive Streams with ØMQ as transport layer
The implementation creates a Akka Extension with the following features:
 1. pubSink that will transmit its data from an Akka Stream onto zeroMQ 
 2. subSource that will receive data over zeroMQ and stream it out to a subsequent Akka Stream
 3. the pubSink and subSource implement the Reactive Streams protocol and as such allows for an end to end push back on the zeroMQ transmission
  