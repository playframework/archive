# PlaySystemMonitor
Web based System Montoring tool for linux writtern using Play web framework Scala

Note: This project depends on top command of the system (This project is writter for Linux TOP command). Looks like Unix top command output structure is different from Linux top command output structure. So, the application breaks on UNIX system(mac). This app is tested on Linux Unbuntu.

=========================================================================================================================

This Application demonstrates the importance of Event streams. Taking data from the server located at data center to the Network monitoring center is defacto now a days. Data analytics plays a crucial role in businesses. A stitch in time saves nine applies here.So, Taking the data from the server to web browser and showing data in terms of Charts is very important for easy comprehension.

# To run this project

git clone https://github.com/pamu/PlaySystemMonitor.git

Go to the application root folder and run activator

```
    ./activator run
```

Activator downloads quite a lot of dependencies in case you don't have it already and then in the browser open
```
    http://localhost:9000
```
