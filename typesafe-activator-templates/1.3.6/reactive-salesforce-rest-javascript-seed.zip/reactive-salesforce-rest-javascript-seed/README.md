Reactive Salesforce Seed with REST and JavaScript
-------------------------------------------------

This Activator template gets you started building Reactive Salesforce apps with REST and JavaScript.  The server uses Java with Play Framework for handling OAUTH and making REST requests to Salesforce.  The web client UI is built with JavaScript, AngularJS, and Bootstrap.

[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy)
