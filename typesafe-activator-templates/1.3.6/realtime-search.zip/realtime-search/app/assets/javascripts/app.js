'use strict';

angular.module('realtimeSearch', ['realtimeSearch.controllers']);