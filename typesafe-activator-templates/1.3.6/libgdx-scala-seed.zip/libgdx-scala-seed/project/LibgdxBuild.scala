import sbt._
import Keys._

object LibgdxBuild {
  def libgdxVersion = "1.3.1"
}
