package com.example.core

import com.badlogic.gdx.Game

class MyGame extends Game {
  override def create() = {
    
  }
}