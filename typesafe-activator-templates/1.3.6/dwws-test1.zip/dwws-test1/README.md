DWWS Seed Template - Silhouette - GitHub Authentication
=======================================================

## Exemplo

[![Fazer deploy no Heroku](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy)

(The "Build App" phase will take a few minutes)

## Status do Build

[![Build Status](https://travis-ci.org/joaoraf/dwws-test1.svg?branch=master)](https://travis-ci.org/joaoraf/dwws-test1)

## Cobertura

[![Coverage Status](https://coveralls.io/repos/joaoraf/dwws-test1/badge.svg)](https://coveralls.io/r/joaoraf/dwws-test1)

# License

The code is licensed under [Apache License v2.0](http://www.apache.org/licenses/LICENSE-2.0).
