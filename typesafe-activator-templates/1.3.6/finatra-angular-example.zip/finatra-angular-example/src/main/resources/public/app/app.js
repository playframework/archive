window.app = angular.module('shoppingCart', ['shoppingCart.site']);

angular.module('shoppingCart.site', ['ngRoute', 'ngResource']);