rabbitmq-akka-streams
=====================

Experimenting with Akka Stream and RabbitMQ client.
