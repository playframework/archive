Apache Spark activator template
===============================

[![Build Status](https://travis-ci.org/jaceklaskowski/spark-activator.svg?branch=master)](https://travis-ci.org/jaceklaskowski/spark-activator)

This is an [Typesafe Activator](http://typesafe.com/platform/getstarted) template to Demonstrate [Apache Spark](http://spark.apache.org) with Scala and Akka.

The motivation: [Go Reactive Activator Contest: Scala Days Edition](http://typesafe.com/blog/go-reactive-activator-contest-scala-days-edition)

### Open questions
* What is Apache Spark Streaming? What are Spark components?
* What are the use cases for Spark and Scala? Akka?