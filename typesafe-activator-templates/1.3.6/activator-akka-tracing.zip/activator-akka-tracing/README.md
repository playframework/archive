Akka Tracing Activator
======================

This tutorial aims to show you how to trace messages inside Akka system.
You will be guided through the tracing basics, sampling, trace logging, hierarchical calls and spray integration.

See project's [github page](https://github.com/levkhomich/akka-tracing) and [wiki](https://github.com/levkhomich/akka-tracing/wiki) for more information.
