Go Reactive Activator
=====================

The motivation: [Go Reactive Activator Contest: Scala Days Edition](http://typesafe.com/blog/go-reactive-activator-contest-scala-days-edition)

### Open questions
* What is Apache Spark? What are Spark components?
* What is Typesafe Activator? How to create one?
* What are the use cases for Spark and Scala?