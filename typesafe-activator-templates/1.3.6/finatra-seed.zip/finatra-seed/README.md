# Finatra Typesafe [Activator](https://www.typesafe.com/get-started) Seed Template

[![Build Status](https://secure.travis-ci.org/twitter/finatra-activator-seed.png?branch=master)](http://travis-ci.org/twitter/finatra-activator-seed?branch=master)

A minimal [activator](https://www.typesafe.com/get-started) seed template for creating a Finatra application.
