package com.gilt

import org.slf4j.LoggerFactory

object HelloWorld extends App {
  
  val logger = LoggerFactory.getLogger("com.gilt.HelloWorld")
  logger.info("Hello World!")

}
