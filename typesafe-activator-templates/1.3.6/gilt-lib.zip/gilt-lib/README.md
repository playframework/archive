## An Activator Template for a Scala library
This is a Typesafe activator template for generating a base scala library 
that is ready to be released to maven central. The template is used in Gilt.  

## License
Copyright 2014 Gilt Groupe, Inc. 
Licensed under the Apache License, Version 2.0: http://www.apache.org/licenses/LICENSE-2.0 
