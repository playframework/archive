play-subcut
===========

A sample Play application, tested with Scalatest, and with the configuration using SubCut.
SubCut offers the ease-of-use of Guice, but with a totally Scala accent (traits over annotations!).
