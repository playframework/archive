# activator-scalismo-seed
A minimal seed template for a [Scalismo](https://github.com/unibas-gravis/scalismo) build
