# Play SQLite Example

Demonstrates how to setup a SQLite datasource for both testing and development using automatic evolutions and Anorm.

### Development

    play "~run"

### Testing

    play "~test-quick"
    
