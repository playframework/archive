activator-callcenter
====================

This template demonstrates various Akka-actor features in the business context of a call center.
