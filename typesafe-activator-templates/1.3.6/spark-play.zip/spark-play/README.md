Spark + Play activator template
===============================

This is an [Typesafe Activator](http://typesafe.com/platform/getstarted) template to demonstrate [Apache Spark](http://spark.apache.org) and Play rest services.

The motivation was [Go Reactive Activator Contest: Scala Days Edition](http://typesafe.com/blog/go-reactive-activator-contest-scala-days-edition)

# Run the activator project

Once you download the activator template, execute `./activator clean run`. and head for urls [http://localhost:9000/count](http://localhost:9000/count), [http://localhost:9000/list](http://localhost:9000/list) or [http://localhost:9000/filter/Scala](http://localhost:9000/filter/Scala)