# macroid-akka-pingpong

This Activator template features Macroid and Akka in a 100%-Scala Android application.
It shows how to make user interfaces composable — with Macroid’s tweaks, snails and UI actions,
and reactive — by using Akka to interconnect interface fragments.
