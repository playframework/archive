object Main {
  def main(args: Array[String]) { println("hello") }
}