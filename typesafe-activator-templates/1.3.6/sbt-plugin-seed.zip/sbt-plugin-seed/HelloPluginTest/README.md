# Sample sbt project

The module is for testing the plugin being developed
