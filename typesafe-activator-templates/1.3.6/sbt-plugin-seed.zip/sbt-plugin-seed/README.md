# An activator seed for creating sbt plugins

[![Build Status](https://travis-ci.org/VoxNova/sbt-plugin-seed.svg?branch=master)](https://travis-ci.org/VoxNova/sbt-plugin-seed)

### Resources

[SBT-Plugin Best Practices](http://www.scala-sbt.org/0.13/docs/Plugins-Best-Practices.html)

[Building Scala/SBT Projects with Travis CI](http://docs.travis-ci.com/user/languages/scala/)

[SBT AutoPlugins Tutorial](http://mukis.de/pages/sbt-autoplugins-tutorial/)

[testing sbt plugins](http://eed3si9n.com/testing-sbt-plugins)
