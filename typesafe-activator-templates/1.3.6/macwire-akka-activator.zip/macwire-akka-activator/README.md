Akka+MacWire Activator
======================

How to do container-less Dependency Injection in Akka with #MacWire? Try this
[Activator](http://www.typesafe.com/activator/template/macwire-akka-activator).

Links:

* [Guide to Dependency Injection in Scala (Akka section)](http://di-in-scala.github.io/#akka)
* [The MacWire project on GitHub](https://www.github.com/adamw/macwire)