package activator.actors

case class CalculateRequest(age: Int, favoriteColor: String)
