package activator.calculator

class InterpretFavoriteColor {
  def forColor(color: String) = color.length
}
