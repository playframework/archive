import play.api.GlobalSettings

object Global extends GlobalSettings
