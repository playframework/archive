[![Build Status](https://semaphoreci.com/api/v1/projects/48e312f7-fa60-40ce-8b91-cbfbab2345d1/458958/badge.svg)](https://semaphoreci.com/arturopala/play-2-4-crud-with-reactive-mongo)      

#Seed for Play Framework 2.4 CRUD application with Macwire, ReactiveMongo and AngularJS

This app is deployed on Heroku: <https://gentle-fortress-7896.herokuapp.com/>

###run

```
$sbt run
```  

