package models

case class TweetForm(
  userName: String,
  text: String)

