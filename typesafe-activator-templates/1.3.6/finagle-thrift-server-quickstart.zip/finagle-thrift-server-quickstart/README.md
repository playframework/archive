finagle-thrift-server-quickstart
================================

This project illustrates how to start working on a [Finagle](https://twitter.github.io/finagle/) [Thrift](https://thrift.apache.org/) Server.

It also includes Scala code generation via [Scrooge](http://twitter.github.io/scrooge/).
