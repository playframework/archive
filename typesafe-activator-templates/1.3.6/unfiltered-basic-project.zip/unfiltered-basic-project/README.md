activator-basic-unfiltered-project
==================================

Activator template for a basic unfiltered project
