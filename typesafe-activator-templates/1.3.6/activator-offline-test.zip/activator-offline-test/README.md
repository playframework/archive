# activator-offline-test
Activator Offline Test Template (for development purposes only)
