# Clustered chat activator

How to build a clustered chat in Play with Websockets and Akka's actors? Try this
[Activator](http://www.typesafe.com/activator/template/clustered-chat).
