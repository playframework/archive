Open all *.conf files and replace {{PROJECT_HOME}} placeholder with path to ddd-leaven-akka-v2 project dir.

Abbreviations:

 * wb - write-back
 * wf - write-front
 * rb - read-back
 * rf - read-front