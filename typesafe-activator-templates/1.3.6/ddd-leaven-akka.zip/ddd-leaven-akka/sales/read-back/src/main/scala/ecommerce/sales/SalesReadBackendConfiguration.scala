package ecommerce.sales

import pl.newicom.dddd.view.sql.SqlViewStoreConfiguration

trait SalesReadBackendConfiguration extends SqlViewStoreConfiguration
