# Simple Play Entitytled example

Activator template with a simple example of using [Entitytled](https://github.com/rsschermer/entitytled)
with Play Framework.

[![Build Status](https://travis-ci.org/RSSchermer/activator-play-entitytled-simple.svg)](https://travis-ci.org/RSSchermer/activator-play-entitytled-simple)
