Play Scala ScalaJS template for TypeSafe Activator
==================================================

Modified play-scala activator template to accomodate scalajs.
This project derives its project structure from [play-with-scalajs-example](https://github.com/vmunier/play-with-scalajs-example)
