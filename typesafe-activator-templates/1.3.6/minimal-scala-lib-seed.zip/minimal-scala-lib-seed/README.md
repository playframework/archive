minimal-scala-lib-seed
=========================

This is a seed project which creates a basic build for a general scala library projects.

* Has *Scalaz*, *ScalaTest* and *ScalaMock* at their latest versions as dependencies.
* Has *sbt-scalariform*, *sbt-scapegoat*, *scalastyle-sbt-plugin* and *sbt-scoverage* sbt plugins
* Test and it folders are setup.
