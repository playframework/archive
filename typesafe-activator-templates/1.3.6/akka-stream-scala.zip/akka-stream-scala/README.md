Akka streams activator template
===============================

[![Build Status](https://travis-ci.org/typesafehub/activator-akka-stream-scala.svg?branch=master)](https://travis-ci.org/typesafehub/activator-akka-stream-scala)

Demonstrate Akka streams in Scala.

Akka Streams is an implementation of [Reactive Streams](http://www.reactive-streams.org/),
which is a standard for asynchronous stream processing with non-blocking backpressure.

