# gold-phone-input

`gold-phone-input` is a Material Design field for entering and formatting a
phone number.

Example:

```html
<gold-phone-input></gold-phone-input>

<gold-phone-input country-code="33" phone-number-pattern="X-XX-XX-XX-XX">
</gold-phone-input>
```
