# paper-input

`<paper-input>` is a Material Design text field.

Contains a number of different features for validation, character counting, and more.
