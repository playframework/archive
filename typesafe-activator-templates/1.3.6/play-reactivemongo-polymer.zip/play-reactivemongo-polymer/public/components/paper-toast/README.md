paper-toast
============

A material design notification toast.
