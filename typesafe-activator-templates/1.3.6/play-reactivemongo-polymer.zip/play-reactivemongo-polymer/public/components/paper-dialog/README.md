# paper-dialog

A Material Design dialog
