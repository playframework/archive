# Play Framework - ReactiveMongo - Polymer

The purpose of this application is to demonstrate a Service Oriented Approach for Single Page App development.

To serve this purpose this application template integrates **Polymer**, **Play Framework** and **MongoDB**.

For sake of this template this [sample app] (https://www.polymer-project.org/docs/start/tutorial/intro.html) available on Polymer website has been used.
