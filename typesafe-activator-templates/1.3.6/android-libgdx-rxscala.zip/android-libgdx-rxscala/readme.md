# Typesafe Activator template for libGDX development with RxScala

## Usage

Browse for "libgdx-rxscala" on the [Typesafe Activator](https://typesafe.com/activator/templates) website,
choose it from within the Activator UI, or start it from the command line via
`activator new PROJECTNAME libgdx-rxscala`.

# Build

To build, you need [sbt](http://scala-sbt.org).

## License

Licensed under Creative Commons CC0 1.0 Universal (CC0). 
See the LICENSE file for details.
