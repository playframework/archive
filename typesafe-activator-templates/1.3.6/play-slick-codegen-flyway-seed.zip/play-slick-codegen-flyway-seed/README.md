See http://flywaydb.org/documentation/sbt/ for flyway usage.
It's already configured to use the play-slick configuration from `application.conf`.

For codegen run `genTables` in sbt.
