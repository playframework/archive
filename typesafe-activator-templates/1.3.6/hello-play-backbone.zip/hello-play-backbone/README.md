hello-play-backbone
===================

Basic activator template that uses backbone.js in a simple way
