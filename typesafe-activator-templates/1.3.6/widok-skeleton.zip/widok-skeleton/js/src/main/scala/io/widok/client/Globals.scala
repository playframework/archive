package io.widok.client

object Globals {
  val brandName = "Widok skeleton"
}
