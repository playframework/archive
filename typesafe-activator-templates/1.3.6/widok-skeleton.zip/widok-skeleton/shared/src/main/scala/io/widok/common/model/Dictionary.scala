package io.widok.common.model

object Dictionary {
  case class Result(text: String)
}
