Typesafe Activator template for Akka and Spring in Java.
