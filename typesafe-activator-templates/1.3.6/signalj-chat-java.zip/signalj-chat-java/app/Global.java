import signalJ.SignalJGlobal;

public class Global extends SignalJGlobal {

}