# Akka HTTP REST Example - Instagram Pictures Filter

[![Build Status](https://travis-ci.org/pvoznenko/akka-http-rest-example.svg)](https://travis-ci.org/pvoznenko/akka-http-rest-example)

Main goal of this project to show an example on how to use Akka HTTP as REST service.

This project will hep you to load your pictures by date range from your Instagram.

# Copyright

Copyright (C) 2015 Pavlo Voznenko.

Distributed under the MIT License.