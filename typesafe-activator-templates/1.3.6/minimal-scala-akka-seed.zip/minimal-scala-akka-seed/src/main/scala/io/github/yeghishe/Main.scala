package io.github.yeghishe

import akka.actor.ActorSystem

object Main extends App {
  private implicit val system = ActorSystem()
}
