play-guice
===========

A sample Play application with the minimum configuration required to support Guice.