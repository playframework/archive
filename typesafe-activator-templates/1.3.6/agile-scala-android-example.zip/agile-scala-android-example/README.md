agile-scala-android-example
===========================

A quick tutorial and overview of the Agile Scala Android SBT plugin.
