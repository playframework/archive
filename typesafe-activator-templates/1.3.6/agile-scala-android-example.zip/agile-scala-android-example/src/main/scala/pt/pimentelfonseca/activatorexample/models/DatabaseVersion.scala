package pt.pimentelfonseca.activatorexample.models

case class DatabaseVersion(version: Long, appliedIn: Long)
{

}
