
INSERT INTO bank VALUES(1, 'SBI bank');

INSERT INTO bank VALUES(2, 'PNB bank');

INSERT INTO bankinfo VALUES(1, 'goverment',1, 10000);

INSERT INTO bankproduct VALUES(1, 'home loan',1);

INSERT INTO bankproduct VALUES(2, 'eduction loan',1);



