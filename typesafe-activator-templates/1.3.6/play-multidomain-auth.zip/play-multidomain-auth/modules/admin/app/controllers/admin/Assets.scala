package controllers.admin

object Assets extends controllers.common.MyAssetsTrait