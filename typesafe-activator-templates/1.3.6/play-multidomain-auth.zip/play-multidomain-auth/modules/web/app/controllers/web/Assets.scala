package controllers.web

object Assets extends controllers.common.MyAssetsTrait