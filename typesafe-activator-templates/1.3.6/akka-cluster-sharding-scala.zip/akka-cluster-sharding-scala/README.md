activator-akka-cluster-sharding-scala
=====================================

Activator template for the Akka Cluster Sharding feature. See [tutorial](https://github.com/typesafehub/activator-akka-cluster-sharding-scala/blob/master/tutorial/index.html).
