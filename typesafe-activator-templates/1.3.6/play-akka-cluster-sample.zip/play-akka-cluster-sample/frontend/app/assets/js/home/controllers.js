/**
 * Dashboard controllers.
 */
define([], function() {
  'use strict';

  var HomeCtrl = function($scope) {

  };
  HomeCtrl.$inject = [ '$scope' ];
  
  var HeaderCtrl = function($scope) {

  };
  HeaderCtrl.$inject = [ '$scope' ];

  return {
    HeaderCtrl : HeaderCtrl,
    HomeCtrl : HomeCtrl
  };

});
