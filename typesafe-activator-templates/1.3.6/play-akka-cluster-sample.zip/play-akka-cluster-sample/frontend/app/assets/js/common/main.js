/**
 * Common functionality.
 */
define(['angular', './services/playRoutes'],
    function(angular) {
  'use strict';

  return angular.module('yourprefix.common', ['common.playRoutes']);
});
