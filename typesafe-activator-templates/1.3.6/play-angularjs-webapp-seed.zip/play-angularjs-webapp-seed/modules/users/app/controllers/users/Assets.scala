package controllers.users

object Assets extends controllers.AssetsBuilder