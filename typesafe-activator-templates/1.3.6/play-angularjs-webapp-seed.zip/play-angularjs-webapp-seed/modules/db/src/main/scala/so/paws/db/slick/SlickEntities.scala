package so.paws.db.slick

import sorm.Entity

trait SlickEntities {

}