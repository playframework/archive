sbt-github-project-template
===========================

Activator template for easy setup of sbt-managed projects on GitHub with Travis-CI, coveralls and other goodies.

An Typesafe Activator to offer hassle-free setup of projects with sbt-managed build that are hosted on GitHub with other supportive sites.
The template comes with the necessary files to use the features of GitHub to make your projects contributors-oriented.

Use the Typesafe Activator template as follows:

    activator new my-favorite-project sbt-github-project-template

where `my-favorite-project` is the name of your project with sbt/activator-managed build.

Change the working directory to `my-favorite-project` and do `git init .`. Create a project on GitHub and add it as a remote with `git remote add`. Push the changes to Github with `git push`.
