Akka streams activator template
===============================

[![Build Status](https://travis-ci.org/typesafehub/activator-akka-stream-java8.svg?branch=master)](https://travis-ci.org/typesafehub/activator-akka-stream-java8)

Demonstrate Akka streams in Java8.

Akka Streams is an implementation of [Reactive Streams](http://www.reactive-streams.org/),
which is a standard for asynchronous stream processing with non-blocking backpressure.

