Play Framework + WebJars
========================

A template for getting started with Play Framework and WebJars.

[Start hacking on the code in Activator](http://typesafe.com/activator/template/webjars-sample-play2)

[![Deploy Instantly on Heroku](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy)
