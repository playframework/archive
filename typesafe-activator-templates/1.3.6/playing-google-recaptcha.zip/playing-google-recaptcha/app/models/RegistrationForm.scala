package models

case class RegistrationForm(
  firstName: String,
  lastName: String,
  email: String,
  phone: String)