package models

case class Task(id: Long, assignee: String, content: String)