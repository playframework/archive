Sample Facebook Canvas Application using Play Framework and restfb
==================================================================

+   Play Framework v.2.3.4
+   restfb v.1.6.16
+   Facebook Javascript SDK

Configuration
============

Modify **appID** and replace it with your appID ( File: **app/views/index.scala.html**)

            FB.init ( {
                appId : '699976683425267',
                xfbml : true,
                version : 'v2.1'
            } ) ;

Demo:
=====

Available at: https://apps.facebook.com/699976683425267/
