play2-crud-activator
====================

[Typesafe Activator](http://typesafe.com/activator) for [play2-crud](https://github.com/hakandilek/play2-crud). 

HOW-TO
================
Please follow [these instructions](http://typesafe.com/activator/template/play2-crud-activator) in order to create an application with typesafe activator.
