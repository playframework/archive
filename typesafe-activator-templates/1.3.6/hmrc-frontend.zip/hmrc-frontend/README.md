hmrc-frontend
=============

This is a Typesafe Activator template for HMRC frontend applications.

To create a new frontend application, use this command:

```
activator new PROJECTNAME hmrc-frontend
```