package utils;

public interface StockQuote {
    public Double newPrice(Double lastPrice);
}
