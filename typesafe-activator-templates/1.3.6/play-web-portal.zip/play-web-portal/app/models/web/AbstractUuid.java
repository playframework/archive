package models.web;

/**
 * Created by theace on 2014-05-20.
 */
public abstract class AbstractUuid {
    public abstract  void doFinally(DesktopObject dobj);
}
