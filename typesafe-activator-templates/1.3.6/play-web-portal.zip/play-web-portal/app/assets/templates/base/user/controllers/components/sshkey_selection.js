App.SshKeySelectionView = Ember.View.extend({
    templateName: 'components/sshkey_selection',
    availableKeys: null,
    selectedKey: null
});
Ember.Handlebars.helper('sshkeyselection-view', App.SshKeySelectionView );
