App.ImageSelectionView = Ember.View.extend({
    templateName: 'components/image_selection',
    availableImages: null,
    distros: null,
    selectedImage: null
});
Ember.Handlebars.helper('imageselection-view', App.ImageSelectionView);
