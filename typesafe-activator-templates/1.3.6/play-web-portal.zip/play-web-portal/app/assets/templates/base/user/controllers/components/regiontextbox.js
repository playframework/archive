App.RegionTextboxView = Ember.View.extend({
    templateName: 'components/regiontextbox',
    slug: null,
    region_name: null
});
Ember.Handlebars.helper('regiontextbox-view', App.RegionTextboxView);
