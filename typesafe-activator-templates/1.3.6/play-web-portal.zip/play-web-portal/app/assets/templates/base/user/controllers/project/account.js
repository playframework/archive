

App.ProjectAccountRoute = App.MainAccountRoute.extend({
});


App.ProjectAccountController = App.MainAccountController.extend({
});