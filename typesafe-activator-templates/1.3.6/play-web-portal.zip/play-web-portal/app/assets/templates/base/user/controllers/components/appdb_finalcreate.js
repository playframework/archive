

App.AppDbFinalCreateView = Ember.View.extend({
  templateName: 'components/appdb_finalcreate'
});
Ember.Handlebars.helper('appdb_finalcreate-view', App.AppDbFinalCreateView );
