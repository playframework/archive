

App.NoDatabaseView = Ember.View.extend({
  templateName: 'components/no_databases'
});
Ember.Handlebars.helper('nodatabases-view', App.NoDatabaseView );
