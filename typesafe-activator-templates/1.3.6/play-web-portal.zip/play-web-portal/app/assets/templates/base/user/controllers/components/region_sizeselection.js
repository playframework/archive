App.RegionSizeSelectionView = Ember.View.extend({
    templateName: 'components/regionsize_selection'
});
Ember.Handlebars.helper('regionsizeselection-view', App.RegionSizeSelectionView);
