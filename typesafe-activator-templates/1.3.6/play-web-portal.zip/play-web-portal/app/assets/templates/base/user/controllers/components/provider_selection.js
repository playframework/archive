App.ProviderSelectionView = Ember.View.extend({
    templateName: 'components/provider_selection'
});
Ember.Handlebars.helper('providerselection-view', App.ProviderSelectionView);
