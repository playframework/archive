//More detailed view dan the App.Servers object

App.Distro = DS.Model.extend({
    name: DS.attr('string'),
    selecteD: DS.attr()
});


/*var inflector = Ember.Inflector.inflector;
inflector.irregular("server", "server");
*/

App.DistroAdapter = CustomRESTAdapter.extend({
     buildURL: function(record, suffix,z ) {
          try {
              return null;
          } catch (e) {
          }
      }
});
