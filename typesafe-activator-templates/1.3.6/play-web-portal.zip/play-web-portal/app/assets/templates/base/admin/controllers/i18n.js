
App.get("i18n").reopen({
    fr : {
            admin: "Administration"
    },
    en : {
            admin: "Admin"
    }
});