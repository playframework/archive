


App.Status = DS.Model.extend({
        success: DS.attr('string'),
        message: DS.attr('string')
});

Ember.Inflector.inflector.uncountable('status');
