# scala-project-template
An activator scala project template with logback, native packager and tests
