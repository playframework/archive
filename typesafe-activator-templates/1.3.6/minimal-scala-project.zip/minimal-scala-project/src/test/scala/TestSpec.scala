
import org.scalatest._

class TestSpec extends WordSpec with MustMatchers {

  "test" should {
    "test function" in {
      pending
    }
  }

}
