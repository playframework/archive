object Main extends App {
  println("Hello world")
}
