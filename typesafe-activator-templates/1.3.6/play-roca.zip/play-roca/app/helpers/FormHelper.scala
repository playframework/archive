package helpers

import play.api.mvc.Accepting

object FormHelper {
  val accept = Accepting("application/x-www-form-urlencoded")
}
