package com.innoq.rocaplay.domain.issues

trait IssuesDomainModule {

  def issueRepository: IssueRepository

}
