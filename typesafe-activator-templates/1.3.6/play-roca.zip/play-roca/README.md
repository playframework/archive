activator-play-roca
===================


Getting Started
---------------

* install [Bower](http://bower.io)
* `bower install` downloads front-end dependencies
