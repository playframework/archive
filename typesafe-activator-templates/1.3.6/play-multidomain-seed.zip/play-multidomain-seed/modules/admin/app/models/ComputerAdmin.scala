package models.admin

import models._

object ComputerAdmin {
	
	def list = Computer.list
	  
}
