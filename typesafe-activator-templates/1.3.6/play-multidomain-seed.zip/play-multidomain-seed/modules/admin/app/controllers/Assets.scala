package controllers.admin

class Assets extends controllers.common.Assets
class SharedResources extends controllers.common.SharedResources