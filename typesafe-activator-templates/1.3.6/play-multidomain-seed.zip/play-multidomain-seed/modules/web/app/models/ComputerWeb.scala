package models.web

import models._

object ComputerWeb {
	
	def list = Computer.list
	  
}
