package controllers.web

class Assets extends controllers.common.Assets
class SharedResources extends controllers.common.SharedResources