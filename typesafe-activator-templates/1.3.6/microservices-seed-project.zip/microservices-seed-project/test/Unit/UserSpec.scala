import collection.mutable.Stack
import org.scalatestplus.play._
import play.api.test.Helpers._

class UserSpec extends PlaySpec {

  "A Demo Unit Test Spec" should {
    "This is a Unit Test demo" in {
      "Demo Unit Test" must endWith("Test")
    }
  }
}
