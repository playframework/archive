activator-advanced-tweetmap-java8
==================================

Activator Template for the Tweetmap Java 8 Exercises
