package video.imageUtils

import java.awt.Color

case class CircleProperties(width: Int, height: Int, color: Color)