Akka streams activator template
===============================

Demonstrate Akka streams in Scala.

Akka Streams is an implementation of [Reactive Streams](http://www.reactive-streams.org/),
which is a standard for asynchronous stream processing with non-blocking backpressure.

