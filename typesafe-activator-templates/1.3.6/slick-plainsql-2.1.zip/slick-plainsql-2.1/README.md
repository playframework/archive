This is a template for [Typesafe Activator](http://typesafe.com/platform/getstarted).
