securesocial-slick-bootstrap3-sample
====================================

A sample starting application with securesocial slick using h2 file database integrated with bootstrap3
