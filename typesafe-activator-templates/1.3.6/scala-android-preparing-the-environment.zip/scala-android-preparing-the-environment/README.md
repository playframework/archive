# Scala on Android: Preparing the environment

This is a template project to work with Scala on Android
 
The project is structured like a typical android project.
 
- AndroidManifest: `src/main`
- Scala source files: `src/main/scala`
- Android resource files: `src/main/res`
  
You can find more information in the post ["Scala on Android: Preparing the Environment"](http://www.47deg.com/blog/scala-on-android-preparing-the-environment)
