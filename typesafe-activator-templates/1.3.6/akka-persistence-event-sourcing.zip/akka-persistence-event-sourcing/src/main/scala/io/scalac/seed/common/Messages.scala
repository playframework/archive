package io.scalac.seed.common

case class Error(message: String)

case class Acknowledge(id: String)
