package shared

case class Task(id: Option[Long], txt: String, done: Boolean)
