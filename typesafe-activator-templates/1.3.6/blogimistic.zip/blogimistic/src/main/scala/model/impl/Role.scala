package model.impl

object Role extends Enumeration {
  type Role = Value
  val ADMIN, CONTRIBUTOR = Value
}
