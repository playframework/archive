package data

class StaleStateException(msg: String) extends Exception(msg)
