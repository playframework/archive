package data

import slick.driver.JdbcProfile

trait Profile {

  val profile: JdbcProfile
}