hello-sbt
=========

Provides an activator template that introduces the reader to sbt
