package org.example

object Hello extends App {
  println("Hello")
}