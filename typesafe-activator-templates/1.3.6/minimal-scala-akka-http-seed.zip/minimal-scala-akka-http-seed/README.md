minimal-scala-akka-http-seed
=========================

This is a seed project to create basic akka http projects.

* Has *Akka*, *Akka Stream*, *Akka Http*, *Scalaz*, *ScalaTest* and *ScalaMock* at their latest versions as dependencies.
* Has *sbt-scalariform*, *sbt-scapegoat*, *scalastyle-sbt-plugin*,
  *sbt-scoverage*, *sbt-revolver*, *sbt-native-packager*  sbt plugins
* Test and it folders are setup.
