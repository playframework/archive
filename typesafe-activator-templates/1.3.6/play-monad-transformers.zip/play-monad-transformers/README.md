play-monad-transformers
===

This a Typesafe Activator template showing how to use Scalaz monad transformers to simplify Play actions.