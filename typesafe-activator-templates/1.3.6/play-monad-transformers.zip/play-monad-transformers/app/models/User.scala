package models

case class User(username: String, email: String)