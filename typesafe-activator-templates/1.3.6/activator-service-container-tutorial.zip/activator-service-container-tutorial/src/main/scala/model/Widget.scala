package model

case class Widget(id: Option[Int], name: String)
