##anonymous_chat
==============

This is a barebone chat application (without nicknames) to illustrate the use of a websocket with Akka actors within a Play Framework appliction.

