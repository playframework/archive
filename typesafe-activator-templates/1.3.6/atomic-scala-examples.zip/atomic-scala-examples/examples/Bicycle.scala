// Bicycle.scala
import com.atomicscala.AtomicTest._

case class Bicycle(riders:Int)
val forTwo = Bicycle(2)
forTwo is "Bicycle(2)" // Nice
