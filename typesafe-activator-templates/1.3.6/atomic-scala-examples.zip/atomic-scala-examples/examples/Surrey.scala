// Surrey.scala
class Surrey(val adornment:String)
val fancy = new Surrey("fringe on top")
println(fancy) // Ugly
