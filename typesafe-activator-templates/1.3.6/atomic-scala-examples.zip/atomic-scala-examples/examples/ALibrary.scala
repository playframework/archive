// ALibrary.scala
package com.yoururl.libraryname
// Components to reuse ...
class X
