// ImportClass.scala
import util.Random

val r = new Random
println(r.nextInt(10))
println(r.nextInt(10))
println(r.nextInt(10))
