// If5.scala

val result = {
  if(99 > 100) { 4 }
  else { 42 }
}
println(result)

/* Output:
42
*/
