// ShowCode.scala
import codelistingtester._
import codevector._
new CodeListingTester(new CodeVector(_))
