// DisplayDuck.scala

val duck = "Duck".toVector
duck.foreach(n => println("> " + n))
