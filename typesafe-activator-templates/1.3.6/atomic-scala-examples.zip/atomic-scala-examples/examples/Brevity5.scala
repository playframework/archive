// Brevity5.scala
"OttoBoughtAnAuto".foreach(c => print(c))
println
"OttoBoughtAnAuto".foreach(print(_))
println
"OttoBoughtAnAuto".foreach(print)
