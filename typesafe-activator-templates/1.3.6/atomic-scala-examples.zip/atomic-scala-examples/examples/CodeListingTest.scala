// CodeListingTest.scala
import codelistingtester._
import codelisting._
new CodeListingTester(CodeListing.apply)
