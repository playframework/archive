// If3.scala

val y:Boolean = { 11 > 12 }

if(!y) {
  println("It's false")
}

/* Output:
It's false
*/
