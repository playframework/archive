// If4.scala

val z:Boolean = false

if(z) {
  println("It's true!")
} else {
  println("It's false")
}

/* Output:
It's false
*/
