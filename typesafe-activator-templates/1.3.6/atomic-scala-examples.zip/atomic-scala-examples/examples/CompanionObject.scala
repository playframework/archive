// CompanionObject.scala
class X
object X
