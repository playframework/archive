// PaintColors.scala
package paintcolors

object Color extends Enumeration {
  type Color = Value
  val red, blue, yellow, purple,
    green, orange, brown = Value
}
