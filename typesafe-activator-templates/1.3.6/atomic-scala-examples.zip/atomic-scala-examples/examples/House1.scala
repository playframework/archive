// House1.scala

trait Building
trait Kitchen
trait House extends Building with Kitchen
