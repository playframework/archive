// ImportMultiple.scala
import util.Random
import util.Properties

val r = new Random
val p = Properties
