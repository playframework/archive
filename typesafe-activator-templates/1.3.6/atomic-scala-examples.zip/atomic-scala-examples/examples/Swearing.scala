// Swearing.scala
import language.postfixOps

class Swearing {
  def #!>% = "Rowzafrazaca!"
}
val x = new Swearing
println(x.#!>%)
println(x #!>%)
