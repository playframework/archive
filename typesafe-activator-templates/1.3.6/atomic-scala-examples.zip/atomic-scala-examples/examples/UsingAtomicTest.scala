// UsingAtomicTest.scala
import com.atomicscala.AtomicTest._

val pi = 3.14
val pie = "A round dessert"

pi is 3.14
pie is "A round dessert"
pie is "Square" // Produces error
