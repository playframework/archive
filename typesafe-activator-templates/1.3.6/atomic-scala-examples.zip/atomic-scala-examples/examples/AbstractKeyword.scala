// AbstractKeyword.scala
abstract class WithValVar {
  val x:Int
  var y:Int
}

abstract class WithMethod {
  def f():Int
  def g(n:Double)
}
