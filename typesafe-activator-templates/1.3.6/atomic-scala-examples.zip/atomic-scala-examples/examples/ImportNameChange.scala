// ImportNameChange.scala
import util.{ Random => Bob,
  Properties => Jill }

val r = new Bob
val p = Jill
