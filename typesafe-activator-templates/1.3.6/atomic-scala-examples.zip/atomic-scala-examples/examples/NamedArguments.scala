// NamedArguments.scala

class Color(red:Int, blue:Int, green:Int)
new Color(red = 80, blue = 9, green = 100)
new Color(80, 9, green = 100)
