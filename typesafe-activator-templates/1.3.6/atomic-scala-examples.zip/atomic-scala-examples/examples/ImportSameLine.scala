// ImportSameLine.scala
import util.Random, util.Properties

val r = new Random
val p = Properties
