// UseALibrary.scala
import com.yoururl.libraryname._
new X
