// If2.scala

val x:Boolean = { 1 > 0 }

if(x) {
  println("It's true!")
}

/* Output:
It's true!
*/
