// ForVector.scala
val v = Vector("Somewhere", "over",
  "the", "rainbow")
for(word <- v) {
  println(word)
}
