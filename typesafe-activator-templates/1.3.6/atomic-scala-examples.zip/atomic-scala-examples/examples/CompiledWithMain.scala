// CompiledWithMain.scala

object EchoArgs2 {
  def main(args:Array[String]) =
    for(arg <- args)
      println(arg)
}
