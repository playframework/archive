// Dog.scala
class Dog {
  def bark():String = { "yip!" }
}
