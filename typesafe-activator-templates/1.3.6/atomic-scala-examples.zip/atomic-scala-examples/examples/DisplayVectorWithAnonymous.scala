// DisplayVectorWithAnonymous.scala

val v = Vector(1, 2, 3, 4)
v.foreach(n => println("> " + n))
