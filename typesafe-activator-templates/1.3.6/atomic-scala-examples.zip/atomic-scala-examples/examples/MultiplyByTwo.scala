// MultiplyByTwo.scala

def multiplyByTwo(x:Int):Int = {
  println("Inside multiplyByTwo")
  x * 2 // Return value
}

val r = multiplyByTwo(5) // Method call
println(r)
/* Output:
Inside multiplyByTwo
10
*/
