// Expressions.scala

val c = {
  val i1 = 2
  val j1 = 4/i1
  i1 * j1
}
println(c)
/* Output:
4
*/
