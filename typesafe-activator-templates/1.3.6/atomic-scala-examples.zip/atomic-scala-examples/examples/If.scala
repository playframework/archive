// If.scala

if(1 > 0) {
  println("It's true!")
}

/* Output:
It's true!
*/
