// FullyQualify.scala

val r = new util.Random
val p = util.Properties
