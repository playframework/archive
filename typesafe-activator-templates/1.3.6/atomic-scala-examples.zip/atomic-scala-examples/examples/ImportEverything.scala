// ImportEverything.scala
import util._

val r = new Random
val p = Properties
