// Hyena.scala

class Hyena {
  println("This is in the class body")
}
val hyena = new Hyena
