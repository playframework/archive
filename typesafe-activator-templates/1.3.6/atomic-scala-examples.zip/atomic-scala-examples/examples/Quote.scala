// Quote.scala
import com.atomicscala.AtomicTest._
import Quoting2._

"Single".singleQuote is "'Single'"
"Double".doubleQuote is "\"Double\""
