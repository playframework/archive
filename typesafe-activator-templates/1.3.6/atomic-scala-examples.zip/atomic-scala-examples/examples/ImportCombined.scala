// ImportCombined.scala
import util.{Random, Properties}

val r = new Random
val p = Properties
