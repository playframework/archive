// Compiled.scala

object WhenAmI extends App {
  hi
  println(new java.util.Date())
  def hi = println("Hello! It's:")
}
