// NamedAndDefaultArgs.scala

class Color2(red:Int = 100,
  blue:Int = 100, green:Int = 100)
new Color2(20)
new Color2(20, 17)
new Color2(blue = 20)
new Color2(red = 11, green = 42)
