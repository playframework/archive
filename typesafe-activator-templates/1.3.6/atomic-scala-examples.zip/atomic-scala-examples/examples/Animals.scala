// Animals.scala

// Create some classes:
class Giraffe
class Bear
class Hippo

// Create some objects:
val g1 = new Giraffe
val g2 = new Giraffe
val b = new Bear
val h = new Hippo

// Each new object is unique:
println(g1)
println(g2)
println(h)
println(b)
