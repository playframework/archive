minimal-scala-specs2
====================

A minimal scala project with specs2 as a testing dependency
