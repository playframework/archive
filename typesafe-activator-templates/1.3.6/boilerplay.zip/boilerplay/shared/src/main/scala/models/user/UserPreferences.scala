package models.user

case class UserPreferences(
  avatar: String = "guest",
  color: String = "greyblue"
)
