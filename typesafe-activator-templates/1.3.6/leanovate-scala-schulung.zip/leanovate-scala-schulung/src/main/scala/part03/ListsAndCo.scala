package part03

object ListsAndCo {

  def fib(n: Int): Int = ???

  def fibList(n: Int): List[Int] = ???

  def fac(n: Int): Int = ???

  def sum(l: List[Int]): Int = ???

  def last(l: List[Int]): Int = ???

  def penultimate(l: List[Int]): Int = ???

  def sizeOfList(l: List[Int]): Int = ???

  def shout(input: Array[String]): Array[String] = ???

  def concatenate(input: Array[String]): String = ???

  def shout(input: Seq[String]): Seq[String] = ???

  def extractWords(input: Seq[String]): Seq[String] = ???

  def countWords(input: Seq[String]): Map[String, Int] = ???

}
