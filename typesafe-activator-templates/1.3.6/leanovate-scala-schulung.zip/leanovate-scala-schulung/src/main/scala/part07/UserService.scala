package part07

class UserService(userDao: UserDao) {

  def findUsersWithFirstName(firstName: String) = ???
}
