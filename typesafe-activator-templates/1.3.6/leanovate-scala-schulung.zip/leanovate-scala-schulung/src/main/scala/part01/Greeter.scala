package part01

object Greeter {
  // implement the three stubs
  // what is the difference between the three versions
  def greetingInEnglish: String = ???
  val greetingInGerman: String = ???
  lazy val greetingInItalian: String = ???
}
