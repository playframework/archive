package part01

class CallByNameAndValue {

  def areBothOdd(x: Int, y: Int) = x % 2 == 1 && y % 2 == 1

}
