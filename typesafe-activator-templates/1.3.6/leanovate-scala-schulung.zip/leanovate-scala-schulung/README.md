# scala-schulung
Scala Schulung
