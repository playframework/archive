#!/bin/bash

sbt "~backend/re-start"