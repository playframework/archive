#!/bin/sh
cd ui
npm install
./node_modules/.bin/grunt server