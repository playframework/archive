# Bootzooka 

Bootzooka is a simple application scaffolding project to allow quick start of development for modern web based
applications.

[See the docs](http://softwaremill.github.io/bootzooka/) for more information.










