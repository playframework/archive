package com.softwaremill.bootzooka.email.sender

case class AttachmentDescription(content: Array[Byte], filename: String, contentType: String)
