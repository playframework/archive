package com.softwaremill.bootzooka.email

case class EmailContentWithSubject(content: String, subject: String)
