package com.mintbeans.geo.core

case class Location(id: org.bson.types.ObjectId, name: String, point: Point)
