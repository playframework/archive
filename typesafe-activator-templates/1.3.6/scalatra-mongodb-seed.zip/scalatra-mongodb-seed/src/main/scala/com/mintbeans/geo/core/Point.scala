package com.mintbeans.geo.core

case class Point(latitude: Double, longitude: Double)

