object Main extends App {
    println("Test Patterns in Scala")
}
