activator-test-patterns-scala
=============================

Activator Test Patterns in Scala

This is a TypeSafe Activator used to kickstart using Scala for testing. It shows common test patterns, paradigmns, and usage with various Scala and Java libraries.
