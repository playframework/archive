Salesforce Canvas Seed
-------------------------------------------------

This Activator template gets you started building Salesforce Canvas apps with Java and Play Framework.

[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy)
