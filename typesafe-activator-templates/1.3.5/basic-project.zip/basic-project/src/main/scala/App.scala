package example

object App {
  def main(args: Array[String]) {
    print("Hello basic-project!")
  }
}
