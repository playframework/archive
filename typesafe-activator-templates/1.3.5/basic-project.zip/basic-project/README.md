This is a an [activator](https://typesafe.com/activator) template for removing
the boilerplate in setting up a new scala project:

* sbt 0.13.5
* Cross build against Scala 2.10.4, 2.11.2
* [ScalaTest](http://www.scalatest.org/)
* [ScalaCheck](http://www.scalacheck.org/)
* Everything in your project's base package imported automatically in repl sessions
