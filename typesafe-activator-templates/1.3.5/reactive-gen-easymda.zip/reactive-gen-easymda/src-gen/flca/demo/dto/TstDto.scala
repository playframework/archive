/*
 * Generated via the com.flca generator
 */
	
package flca.demo.dto
	
import com.easymda.util.BaseClass
import com.easymda.util.FetchDepth
import java.util.Date
/**
 generated class
*/
case class TstDto( var dtoId:Option[Long]=None, var dtoName:Option[String]=None, var count:Option[Int]=None, var dob:Option[Date]=None) {
  
}
