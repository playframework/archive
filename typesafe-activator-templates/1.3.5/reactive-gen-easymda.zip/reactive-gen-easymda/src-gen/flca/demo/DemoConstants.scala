/*
 * Generated via the com.flca generator
 */
	
package flca.demo
	
  
object DemoConstants {
  val HTTP_PORT = 8000
  val TIMEOUT = 25
  val CURL_CMD = """curl -i -H "Accept: application/json" -H "Content-Type:application/json" -X GET --data """  
}  
