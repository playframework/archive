/*
 * Generated via the com.flca generator
 */
	
package flca.demo.entity.srv
	
import flca.demo.entity.srv.mock.TstaDaoSrvMock
 
object TstaDaoSrvFact {
  def get() : TstaDaoSrv = {
    TstaDaoSrvImpl
  }
}
