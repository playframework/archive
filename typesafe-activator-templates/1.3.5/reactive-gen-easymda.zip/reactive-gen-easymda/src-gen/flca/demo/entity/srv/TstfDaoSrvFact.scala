/*
 * Generated via the com.flca generator
 */
	
package flca.demo.entity.srv
	
import flca.demo.entity.srv.mock.TstfDaoSrvMock
 
object TstfDaoSrvFact {
  def get() : TstfDaoSrv = {
    TstfDaoSrvImpl
  }
}
