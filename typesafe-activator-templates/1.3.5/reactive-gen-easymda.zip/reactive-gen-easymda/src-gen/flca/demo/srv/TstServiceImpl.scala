 
/*
 * Generated via the com.flca generator
 */
	
package flca.demo.srv
	
import flca.demo.dto.TstDto
import flca.demo.entity.Tsta
import scala.slick.jdbc.JdbcBackend.Database
/**
 * 
 *
 * @author robin
 * @version $Id: ServiceIntf.jet,v 1.1 rbakkerus Exp $
 * @generated
 */
object TstServiceImpl extends TstService {
 
	/**
	 * todo
	 */
	def helloWorld() : String = {
    null
	}
	/**
	 * todo
	 */
	def pingMe(aMessage1:String,  aMessage2:String) : String = {
    null
	}
	/**
	 * todo
	 */
	def saveTestA(aValue:Tsta) : Tsta = {
    null
	}
	/**
	 * todo
	 */
	def searchTestA(aName:String) : List[Tsta] = {
    null
	}
	/**
	 * todo
	 */
	def getDto(aValue:TstDto) : TstDto = {
    null
	}
	/**
	 * todo
	 */
	def ping(aMessage:String) : String = {
    null
	}
	/**
	 * todo
	 */
	def doSomething() : Unit = {
    
	}
}
