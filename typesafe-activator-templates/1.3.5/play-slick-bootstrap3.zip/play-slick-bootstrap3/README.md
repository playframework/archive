Activator template for Play Framework and the Slick database and bootstrap3 access library.
You can also execute 'slick code generetor' from the top page.
![top page](tutorial/top-page.png)