package innovint

import org.scalatest.{ MustMatchers, WordSpec }

class EmptyScalaTest extends WordSpec with MustMatchers {

  "addition" should {
    "handle (1 + 2) + 3" in {
      (1 + 2) + 3 must be (6)
    }

    "handle 1 + ( 2 + 3 )" in { 1 + ( 2 + 3 ) must be (6) }
  }
}