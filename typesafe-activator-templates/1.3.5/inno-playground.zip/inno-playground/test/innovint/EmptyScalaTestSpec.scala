package innovint

import org.scalatest.{ WordSpec, MustMatchers }
import org.scalatest.prop.PropertyChecks

class EmptyScalaTestSpec extends WordSpec with PropertyChecks with MustMatchers {
    "addition" should {
      "not change when adding 0" in forAll { int :Int =>
        int + 0 must be(int)
      }
    }
}