activator-akka-scala-seed
=========================

A minimal seed template for an Akka with Scala build 
