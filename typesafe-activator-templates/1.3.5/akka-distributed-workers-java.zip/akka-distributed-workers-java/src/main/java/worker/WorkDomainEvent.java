package worker;

public interface WorkDomainEvent {

}
