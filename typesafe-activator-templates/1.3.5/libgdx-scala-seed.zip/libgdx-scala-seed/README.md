# libGDX Scala Seed
This is a Typesafe Activator seed that generates a barebones
[libGDX](http://libgdx.badlogicgames.com/) project. The generated project uses
Scala and the sbt-libgdx plugin.

# Usage
Use Typesafe Activator to create a project based on this template. Edit the
project name in `build.sbt`.

See the [sbt-libgdx](http://github.com/Technius/sbt-libgdx) plugin for
configuration options and commands.
