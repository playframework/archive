play-spring-data-jpa
====================

A sample application demonstrating play-java using Spring Data JPA along with Spring Core.