activator-akka-java-seed
========================

A minimal seed template for an Akka with Java build
