## An Activator Template for a Multi Project Play App 
This is a Typesafe activator template for generating a base multi project 
Play application. The template is used in Gilt.  

## API Generation
The Controllers for the Play are generated from a JSON file (api.json) via
a sbt generate-api... more to come.

## License
Copyright 2014 Gilt Groupe, Inc. 
Licensed under the Apache License, Version 2.0: http://www.apache.org/licenses/LICENSE-2.0 
