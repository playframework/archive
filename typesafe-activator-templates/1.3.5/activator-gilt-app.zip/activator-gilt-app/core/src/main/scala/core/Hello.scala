package core

object Hello extends App {
    println("Hello, world! from core")
}
