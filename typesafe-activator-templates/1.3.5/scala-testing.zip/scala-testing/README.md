Scala Testing
===============

A sample application demonstrating unit testing with various frameworks: ScalaTest, Specs2, Scalacheck, JUnit, and TestNG.

This template is a companion to the <a href="https://www.youtube.com/watch?v=W9yMkao_AZg">Scala Testing video</a> on the <a href="https://www.youtube.com/user/typesafehub">Typesafe YouTube channel</a>. You can find the slides from the video in the "presentation" directory of the project.