# Hello Scaladin

This is a template for the Typesafe Activator platform. This template creates a simple Scaladin application, deploys it on an embedded Jetty server and runs the server.
