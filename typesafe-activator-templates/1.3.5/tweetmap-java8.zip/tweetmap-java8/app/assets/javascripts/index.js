var app = angular.module('tweetMapApp', []);

