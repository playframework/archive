This is an example of Play 2.4 application that uses Scaldi for dependency injection.

It can be also found as an activator template here:

http://www.typesafe.com/activator/template/scaldi-play-example