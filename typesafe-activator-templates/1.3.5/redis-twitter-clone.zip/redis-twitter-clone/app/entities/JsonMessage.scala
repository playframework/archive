package entities

/**
 * marker trait for classes with implicit JSON converters in their companion objects
 */
trait JsonMessage {
}
