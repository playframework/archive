###Important!

CloudTimer is a web application, it means that application is running only  
when it is opened inside the browser.  
  
In order to have tasks running, you have to leave tasks page opened,  
it's not required that application is focused,  
you need only to open it and after you can switch to any other page or application.  

###Double click Edit

Inside tasks page you can't see any edit button, however every field, name time and goal,  
of created tasks, is editable, just double-click on field you want to edit.  

###Groups

Groups are a way to group your tasks,  
To create a group just add one hashtag, a word starting with '#' character,  
on the tasks name, for people using Twitter, hashtag concept should be very familiar.  
  
For example, to create group 'myProjects',  
create a task with name 'Example task #myProject'  
and you'll see the group in the groups selectbox.

###Notifications

It is very useful to be notified when a task with goal reached that goal,  
so let application notify you with a desktop notification.  
The first time application start,it ask you if you want activate notifications,  
if you refused first time, just go to User -> Settings page and reactive them.  
  
If you activated notifications, but when a task reach their goal nothing happen,  
go on browser settings under contents settings,  
and verify that notifications are enabled for www.cloudtimr.com  

###Export

Likely you want save daily status of your tasks and  
CloudTimer helps you to achieve that.  
  
At the bottom of the tasks page, you can see a download button,  
this button export tasks in **csv** format, with the date of the current day in the  
file name. If there is no one group selected, all tasks are exported,  
otherwise it export only tasks of selected group, adding the name of  
the group to the file name.  

