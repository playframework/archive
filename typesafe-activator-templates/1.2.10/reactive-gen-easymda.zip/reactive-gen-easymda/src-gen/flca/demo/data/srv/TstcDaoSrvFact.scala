/*
 * Generated via the com.flca generator
 */
	
package flca.demo.data.srv
	
import flca.demo.data.srv.mock.TstcDaoSrvMock
 
object TstcDaoSrvFact {
  def get() : TstcDaoSrv = {
    TstcDaoSrvImpl
  }
}
