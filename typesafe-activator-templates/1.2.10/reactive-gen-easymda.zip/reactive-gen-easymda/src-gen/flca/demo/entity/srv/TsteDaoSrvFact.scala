/*
 * Generated via the com.flca generator
 */
	
package flca.demo.entity.srv
	
import flca.demo.entity.srv.mock.TsteDaoSrvMock
 
object TsteDaoSrvFact {
  def get() : TsteDaoSrv = {
    TsteDaoSrvImpl
  }
}
