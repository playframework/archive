 
/*
 * Generated via the com.flca generator
 */
	
package flca.demo.srv
	
import flca.demo.srv.mock.TstServiceMock
 
object TstServiceFact {
  def get() : TstService = {
    TstServiceImpl
  }
}
