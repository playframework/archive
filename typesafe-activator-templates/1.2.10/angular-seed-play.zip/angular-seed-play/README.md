angular-seed-play
=================

This project illustrates how [WebJars](http://www.webjars.org/) can be used along with
[requirejs](http://requirejs.org/) in relation to the popular
[angular-seed](https://github.com/angular/angular-seed) project.

The project is available as a [Typesafe Activator Template](http://typesafe.com/activator/template/angular-seed-play).
