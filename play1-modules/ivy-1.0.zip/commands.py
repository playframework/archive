import sys,os,inspect

if play_command == 'new' or play_command == "ivy:init":
    module_dir = inspect.getfile(inspect.currentframe()).replace("commands.py","")
    shutil.copyfile(os.path.join(module_dir,'resources/build.xml'), os.path.join(application_path, 'build.xml'))
    shutil.copyfile(os.path.join(module_dir,'resources/ivy.xml'), os.path.join(application_path, 'ivy.xml'))

if play_command == 'ivy:up' or play_command == 'ivy:update':
    print "~"
    print "~ Retriving dependencies..."
    print "~"
    os.system('ant')

if play_command == 'ivy:re' or play_command == 'ivy:refresh':
    print "~"
    print "~ Refresh dependencies..."
    print "~"
    os.system('ant clean resolve')

if play_command == 'ivy:dep' or play_command == 'ivy:dependencies' :
    print "~~~~~~~~~~~~~~~~~~~~~"
    print "~ Core dependencies ~"
    print "~~~~~~~~~~~~~~~~~~~~~"
    for jar in os.listdir(os.path.join(play_base, 'framework/lib')):
        if jar.endswith('.jar'):
            print(jar)
    print "\n"
    print "~~~~~~~~~~~~~~~~~~~~~~~"
    print "~ Module dependencies ~"
    print "~~~~~~~~~~~~~~~~~~~~~~~"
    for module in modules:
        if os.path.exists(os.path.join(module, 'lib')):
            libs = os.path.join(module, 'lib')
            if os.path.exists(libs):
                for jar in os.listdir(libs):
                    if jar.endswith('.jar'):
                            print(jar)
    print "\n"
    print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    print "~ Application dependencies ~"
    print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    for jar in os.listdir(os.path.join(application_path, 'lib')):
        print(jar) 
    print "\n"

sys.exit(0)    
