package controllers.t3;

import cn.bran.play.JapidController2;
public class App extends JapidController2 {
	public static void foo() {
		renderText("hi foo  ");
	}
}
