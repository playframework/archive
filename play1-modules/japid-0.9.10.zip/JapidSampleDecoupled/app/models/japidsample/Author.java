package models.japidsample;

import java.util.Date;

public class Author {
	public String name;
	public Date birthDate;
	public char gender;
	public String publisher;
	public String publisher2;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	@Override
	public String toString() {
		return name + birthDate;
	}
	
	 
}
