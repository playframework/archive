This sample application is a port of a Wicket application created by zenika.
http://blog.zenika.com/index.php?post/2009/03/10/Concours-Développer-une-application-web-en-Wicket3 