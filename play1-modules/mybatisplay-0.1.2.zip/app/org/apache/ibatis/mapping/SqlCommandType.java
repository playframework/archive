package org.apache.ibatis.mapping;

public enum SqlCommandType {
  UNKNOWN, INSERT, UPDATE, DELETE, SELECT;

}
