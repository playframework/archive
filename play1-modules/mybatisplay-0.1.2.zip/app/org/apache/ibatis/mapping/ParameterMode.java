package org.apache.ibatis.mapping;

public enum ParameterMode {
  IN, OUT, INOUT
}
