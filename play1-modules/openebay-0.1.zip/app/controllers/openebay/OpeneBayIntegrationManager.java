package controllers.openebay;

import play.mvc.Controller;

public class OpeneBayIntegrationManager extends Controller {
	public static void index() {
		String message = "success";
		renderJSON(message);
	}
}
