package controllers;

import models.OtherIdStringModel2;
 
@CRUD.For(OtherIdStringModel2.class)
public class OtherIdStringModels2 extends controllers.CRUD {    

}
