package controllers;

import models.Thing;
 
@CRUD.For(Thing.class)
public class Things extends controllers.CRUD {    

}
