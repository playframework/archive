package com.greenlaw110.rythm.play.utils;

import com.greenlaw110.rythm.spi.IExpressionProcessor;
import com.greenlaw110.rythm.spi.Token;

/**
 * Created with IntelliJ IDEA.
 * User: luog
 * Date: 28/03/12
 * Time: 8:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class CacheForProcessor implements IExpressionProcessor {
    @Override
    public boolean process(String exp, Token token) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
