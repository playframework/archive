
import play.utils.Utils;
import play.Play;
import play.exceptions.SourceAttachment;
import com.greenlaw110.rythm.utils.S;
import play.templates.JavaExtensions;
import controllers.*;
import models.*;
import java.util.*;
import java.io.*;
public class app_views_tags_rythm_e500_html__R_T_C__ extends com.greenlaw110.rythm.template.TagBase {
@Override public java.lang.String getName() {
	return "e500";
}

		protected play.exceptions.PlayException exception=null;
		protected play.mvc.Scope.Flash flash=null;
		protected java.util.List<play.data.validation.Error> errors=null;
		protected java.util.Map<String, java.util.List<play.data.validation.Error>> error=null;
		protected play.mvc.Scope.Session session=null;
		protected play.mvc.Http.Request request=null;
		protected java.lang.String _response_encoding=null;
		protected play.mvc.Scope.Params params=null;
		protected java.lang.String lang=null;
		protected play.i18n.Messages messages=null;
		protected play.Play _play=null;
	@SuppressWarnings("unchecked") public void setRenderArgs(java.util.Map<String, Object> args) {
	if (null != args && args.containsKey("exception")) this.exception=(play.exceptions.PlayException)args.get("exception");
	if (null != args && args.containsKey("flash")) this.flash=(play.mvc.Scope.Flash)args.get("flash");
	if (null != args && args.containsKey("errors")) this.errors=(java.util.List<play.data.validation.Error>)args.get("errors");
	if (null != args && args.containsKey("error")) this.error=(java.util.Map<String, java.util.List<play.data.validation.Error>>)args.get("error");
	if (null != args && args.containsKey("session")) this.session=(play.mvc.Scope.Session)args.get("session");
	if (null != args && args.containsKey("request")) this.request=(play.mvc.Http.Request)args.get("request");
	if (null != args && args.containsKey("_response_encoding")) this._response_encoding=(java.lang.String)args.get("_response_encoding");
	if (null != args && args.containsKey("params")) this.params=(play.mvc.Scope.Params)args.get("params");
	if (null != args && args.containsKey("lang")) this.lang=(java.lang.String)args.get("lang");
	if (null != args && args.containsKey("messages")) this.messages=(play.i18n.Messages)args.get("messages");
	if (null != args && args.containsKey("_play")) this._play=(play.Play)args.get("_play");
	super.setRenderArgs(args);
}
@SuppressWarnings("unchecked") public void setRenderArgs(Object... args) {
	int p = 0, l = args.length;
	if (p < l) { Object v = args[p++]; boolean isString = ("java.lang.String".equals("play.exceptions.PlayException") || "String".equals("play.exceptions.PlayException")); exception = (play.exceptions.PlayException)(isString ? (null == v ? "" : v.toString()) : v); }
}
@SuppressWarnings("unchecked") @Override public void setRenderArg(String name, Object arg) {
	if ("exception".equals(name)) this.exception=(play.exceptions.PlayException)arg;
	if ("flash".equals(name)) this.flash=(play.mvc.Scope.Flash)arg;
	if ("errors".equals(name)) this.errors=(java.util.List<play.data.validation.Error>)arg;
	if ("error".equals(name)) this.error=(java.util.Map<String, java.util.List<play.data.validation.Error>>)arg;
	if ("session".equals(name)) this.session=(play.mvc.Scope.Session)arg;
	if ("request".equals(name)) this.request=(play.mvc.Http.Request)arg;
	if ("_response_encoding".equals(name)) this._response_encoding=(java.lang.String)arg;
	if ("params".equals(name)) this.params=(play.mvc.Scope.Params)arg;
	if ("lang".equals(name)) this.lang=(java.lang.String)arg;
	if ("messages".equals(name)) this.messages=(play.i18n.Messages)arg;
	if ("_play".equals(name)) this._play=(play.Play)arg;
	super.setRenderArg(name, arg);
}
@SuppressWarnings("unchecked") public void setRenderArg(int pos, Object arg) {
int p = 0;
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.exceptions.PlayException") || "String".equals("play.exceptions.PlayException")); exception = (play.exceptions.PlayException)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Scope.Flash") || "String".equals("play.mvc.Scope.Flash")); flash = (play.mvc.Scope.Flash)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.util.List<play.data.validation.Error>") || "String".equals("java.util.List<play.data.validation.Error>")); errors = (java.util.List<play.data.validation.Error>)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.util.Map<String, java.util.List<play.data.validation.Error>>") || "String".equals("java.util.Map<String, java.util.List<play.data.validation.Error>>")); error = (java.util.Map<String, java.util.List<play.data.validation.Error>>)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Scope.Session") || "String".equals("play.mvc.Scope.Session")); session = (play.mvc.Scope.Session)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Http.Request") || "String".equals("play.mvc.Http.Request")); request = (play.mvc.Http.Request)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.lang.String") || "String".equals("java.lang.String")); _response_encoding = (java.lang.String)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Scope.Params") || "String".equals("play.mvc.Scope.Params")); params = (play.mvc.Scope.Params)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.lang.String") || "String".equals("java.lang.String")); lang = (java.lang.String)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.i18n.Messages") || "String".equals("play.i18n.Messages")); messages = (play.i18n.Messages)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.Play") || "String".equals("play.Play")); _play = (play.Play)(isString ? (null == v ? "" : v.toString()) : v); }
	if(0 == pos) setRenderArg("arg", arg);
}
@Override public com.greenlaw110.rythm.utils.TextBuilder build(){
	out().ensureCapacity(4131);p(""); //line: 1
p("\n<style type=\"text/css\">\n    html, body {\n        margin: 0;\n        padding: 0;\n        font-family: Helvetica, Arial, Sans;\n        background: #EEEEEE;\n    }\n    .block {\n        padding: 20px;\n        border-bottom: 1px solid #aaa;\n    }\n    #header h1 {\n        font-weight: normal;\n        font-size: 28px;\n        margin: 0;\n    }\n    #more {\n        color: #666;\n        font-size: 80%;\n        border: none;\n    }\n    #header {\n        background: #fcd2da;\n    }\n    #header p {\n        color: #333;\n    }\n    #source {\n        background: #f6f6f6;\n    }\n    #source h2 {\n        font-weight: normal;\n        font-size: 18px;\n        margin: 0 0 10px 0;\n    }\n    #source .lineNumber {\n        float: left;\n        display: block;\n        width: 40px;\n        text-align: right;\n        margin-right: 10px;\n        font-size: 14px;\n        font-family: monospace;\n        background: #333;\n        color: #fff;\n    }\n    #source .line {\n        clear: both;\n        color: #333;\n        margin-bottom: 1px;\n    }\n    #source pre {\n        font-size: 14px;\n        margin: 0;\n        overflow-x: hidden;\n    }\n    #source .error {\n        color: #c00 !important;\n    }\n    #source .error .lineNumber {\n        background: #c00;\n    }\n    #source a {\n        text-decoration: none;\n    }\n    #source a:hover * {\n        cursor: pointer !important;\n    }\n    #source a:hover pre {\n        background: #FAFFCF !important;\n    }\n	#source em {\n		font-style: normal;\n		text-decoration: underline;\n		font-weight: bold;\n	}\n	#source strong {\n		font-style: normal;\n		font-weight: bold;\n	}\n</style>\n"); //line: 85
p(" "); //line: 85
if (exception instanceof play.exceptions.PlayException) {p("\n    <div id=\"header\" class=\"block\">\n        <h1>\n            "); //line: 89

p(exception.getErrorTitle());p("\n        </h1>\n        "); //line: 91
if ("DEV".equals(Play.mode.name())) {p("\n        <p>\n            "); //line: 93

p(exception.getErrorDescription());p("\n        </p>\n        "); //line: 95
}else if ("PROD".equals(Play.mode.name())) {p("\n        <p>\n            Error details are not displayed when Play! is in PROD mode. Check server logs for detail.\n        </p>\n        "); //line: 99
}p("\n    </div>\n    "); //line: 101
if (exception.isSourceAvailable() && (null != exception.getLineNumber()) && "DEV".equals(Play.mode.name())) {p("\n    <div id=\"source\" class=\"block\">\n        <h2>In "); //line: 103

p(exception.getSourceFile());p(" (around line "); //line: 103

p(exception.getLineNumber());p(")</h2>\n        "); //line: 104
 //line: 105
            final List<String> source = ((SourceAttachment)exception).getSource(); //line: 106
            int lineNumber = ((SourceAttachment)exception).getLineNumber(); //line: 107
            final int from = lineNumber - 5 >= 0 && lineNumber < source.size() ? lineNumber - 5 : 0; //line: 108
            final int to = lineNumber + 5  < source.size() ? lineNumber + 5 : source.size()-1; //line: 109
            final List<String> lines = new ArrayList(); //line: 110
            for (int i = from; i < to; ++i) { //line: 111
                lines.add(source.get(i)); //line: 112
            } //line: 113
         //line: 114
;p("\n        "); //line: 114

com.greenlaw110.rythm.runtime.Each.INSTANCE.render(lines, new com.greenlaw110.rythm.runtime.Each.Looper<String>(app_views_tags_rythm_e500_html__R_T_C__.this, 581) {
	public void render(final String  line, final int  line_size, final int  line_index, final boolean  line_isOdd, final String  line_parity, final boolean  line_isFirst, final boolean  line_isLast) {
p((null != Utils.open(exception.getSourceFile(), line_index+from) ? ("<a href='" + Utils.open(exception.getSourceFile(), line_index+from) + "'>") : ""));p("\n                <div class=\"line "); //line: 116

p((exception.getLineNumber() == line_index+from ? "error":""));p(" \">\n                    <span class=\"lineNumber\">"); //line: 117

p((line_index+from));p(":</span>\n                    <pre>"); //line: 118
p("&"); //line: 118
p("nbsp;"); //line: 118

p(line.replace("&darr;", "<strong>&darr;</strong>").replace("\000", "<em>").replace("\001", "</em>"));p("</pre>\n                </div>\n            "); //line: 120

p((null == Utils.open(exception.getSourceFile(), line_index+from) ? "</a>" : ""));p("\n        "); //line: 121

	}
});p("\n    </div>\n    "); //line: 123
}p("\n	"); //line: 124
 String moreHtml = exception.getMoreHTML()  //line: 125
;p("\n	"); //line: 125
if (null != moreHtml) {p("\n		<div id=\"specific\" class=\"block\">\n			"); //line: 127

p(moreHtml);p("\n		</div>\n	"); //line: 129
}p("\n    <div id=\"more\" class=\"block\">\n        This exception has been logged with id <strong>"); //line: 131

p(exception.getId());p("</strong>\n    </div>\n"); //line: 133
}else {p("\n    <div id=\"header\" class=\"block\">\n        <h1>"); //line: 135

p((null == exception.getMessage() ? "" : exception.getMessage()));p("</h1>\n    </div>\n"); //line: 137
}p("\n"); //line: 138
p(""); //line: 139

return this;
}
}