
import play.templates.JavaExtensions;
import controllers.*;
import models.*;
import java.util.*;
import java.io.*;
public class app_views_Application_list_html__R_T_C__ extends app_views_main_html__R_T_C__ {//<extended_resource_key>/app/views/main.html</extended_resource_key>
@Override public java.lang.String getName() {
	return "app_views_Application_list_html__R_T_C__";
}

		protected List<Contact> contacts=null;
		protected play.mvc.Scope.Flash flash=null;
		protected java.util.List<play.data.validation.Error> errors=null;
		protected java.util.Map<String, java.util.List<play.data.validation.Error>> error=null;
		protected play.mvc.Scope.Session session=null;
		protected play.mvc.Http.Request request=null;
		protected java.lang.String _response_encoding=null;
		protected play.mvc.Scope.Params params=null;
		protected java.lang.String lang=null;
		protected play.i18n.Messages messages=null;
		protected play.Play _play=null;
	@SuppressWarnings("unchecked") public void setRenderArgs(java.util.Map<String, Object> args) {
	if (null != args && args.containsKey("contacts")) this.contacts=(List<Contact>)args.get("contacts");
	if (null != args && args.containsKey("flash")) this.flash=(play.mvc.Scope.Flash)args.get("flash");
	if (null != args && args.containsKey("errors")) this.errors=(java.util.List<play.data.validation.Error>)args.get("errors");
	if (null != args && args.containsKey("error")) this.error=(java.util.Map<String, java.util.List<play.data.validation.Error>>)args.get("error");
	if (null != args && args.containsKey("session")) this.session=(play.mvc.Scope.Session)args.get("session");
	if (null != args && args.containsKey("request")) this.request=(play.mvc.Http.Request)args.get("request");
	if (null != args && args.containsKey("_response_encoding")) this._response_encoding=(java.lang.String)args.get("_response_encoding");
	if (null != args && args.containsKey("params")) this.params=(play.mvc.Scope.Params)args.get("params");
	if (null != args && args.containsKey("lang")) this.lang=(java.lang.String)args.get("lang");
	if (null != args && args.containsKey("messages")) this.messages=(play.i18n.Messages)args.get("messages");
	if (null != args && args.containsKey("_play")) this._play=(play.Play)args.get("_play");
	super.setRenderArgs(args);
}
@SuppressWarnings("unchecked") public void setRenderArgs(Object... args) {
	int p = 0, l = args.length;
	if (p < l) { Object v = args[p++]; boolean isString = ("java.lang.String".equals("List<Contact>") || "String".equals("List<Contact>")); contacts = (List<Contact>)(isString ? (null == v ? "" : v.toString()) : v); }
}
@SuppressWarnings("unchecked") @Override public void setRenderArg(String name, Object arg) {
	if ("contacts".equals(name)) this.contacts=(List<Contact>)arg;
	if ("flash".equals(name)) this.flash=(play.mvc.Scope.Flash)arg;
	if ("errors".equals(name)) this.errors=(java.util.List<play.data.validation.Error>)arg;
	if ("error".equals(name)) this.error=(java.util.Map<String, java.util.List<play.data.validation.Error>>)arg;
	if ("session".equals(name)) this.session=(play.mvc.Scope.Session)arg;
	if ("request".equals(name)) this.request=(play.mvc.Http.Request)arg;
	if ("_response_encoding".equals(name)) this._response_encoding=(java.lang.String)arg;
	if ("params".equals(name)) this.params=(play.mvc.Scope.Params)arg;
	if ("lang".equals(name)) this.lang=(java.lang.String)arg;
	if ("messages".equals(name)) this.messages=(play.i18n.Messages)arg;
	if ("_play".equals(name)) this._play=(play.Play)arg;
	super.setRenderArg(name, arg);
}
@SuppressWarnings("unchecked") public void setRenderArg(int pos, Object arg) {
int p = 0;
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("List<Contact>") || "String".equals("List<Contact>")); contacts = (List<Contact>)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Scope.Flash") || "String".equals("play.mvc.Scope.Flash")); flash = (play.mvc.Scope.Flash)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.util.List<play.data.validation.Error>") || "String".equals("java.util.List<play.data.validation.Error>")); errors = (java.util.List<play.data.validation.Error>)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.util.Map<String, java.util.List<play.data.validation.Error>>") || "String".equals("java.util.Map<String, java.util.List<play.data.validation.Error>>")); error = (java.util.Map<String, java.util.List<play.data.validation.Error>>)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Scope.Session") || "String".equals("play.mvc.Scope.Session")); session = (play.mvc.Scope.Session)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Http.Request") || "String".equals("play.mvc.Http.Request")); request = (play.mvc.Http.Request)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.lang.String") || "String".equals("java.lang.String")); _response_encoding = (java.lang.String)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Scope.Params") || "String".equals("play.mvc.Scope.Params")); params = (play.mvc.Scope.Params)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.lang.String") || "String".equals("java.lang.String")); lang = (java.lang.String)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.i18n.Messages") || "String".equals("play.i18n.Messages")); messages = (play.i18n.Messages)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.Play") || "String".equals("play.Play")); _play = (play.Play)(isString ? (null == v ? "" : v.toString()) : v); }
	if(0 == pos) setRenderArg("arg", arg);
}
@Override public com.greenlaw110.rythm.utils.TextBuilder build(){
	out().ensureCapacity(2478);p("\n"); //line: 1

_setRenderProperty("title","List");p("\n<table>\n	<thead>\n		<tr>\n			<th class=\"name\">Name</th>\n			<th class=\"firstname\">First name</th>\n			<th class=\"birthdate\">Birth date</th>\n			<th class=\"email\">Email</th>\n			<th class=\"edit\"></th>\n		</tr>\n	</thead>\n	<tbody>\n	    "); //line: 15

com.greenlaw110.rythm.runtime.Each.INSTANCE.render(contacts, new com.greenlaw110.rythm.runtime.Each.Looper<Contact>(app_views_Application_list_html__R_T_C__.this, 382) {
	public void render(final Contact  contact, final int  contact_size, final int  contact_index, final boolean  contact_isOdd, final String  contact_parity, final boolean  contact_isFirst, final boolean  contact_isLast) {p("<tr class=\"contact\" contactId=\""); //line: 16

p(contact.id);p("\" draggable=\"true\">\n   			<td id=\"name-"); //line: 17

p(contact.id);p("\">"); //line: 17

p(contact.name);p("</td>\n   			<td id=\"firstname-"); //line: 18

p(contact.id);p("\">"); //line: 18

p(contact.firstname);p("</td>\n   			<td id=\"birthdate-"); //line: 19

p(contact.id);p("\">"); //line: 19

p(JavaExtensions.format(contact.birthdate, "yyyy-MM-dd"));p("</td>\n   			<td id=\"email-"); //line: 20

p(contact.id);p("\">"); //line: 20

p(contact.email);p("</td>\n   			<td><a href=\""); //line: 21
p(new com.greenlaw110.rythm.play.utils.ActionBridge(false).invokeMethod("form", new Object[] {contact.id})); // line: 80
p("\">"); //line: 21
p("&"); //line: 21
p("gt;</a></td>\n   		</tr>\n	    "); //line: 23

	}
});p("\n	    <tr>\n	        <form action=\""); //line: 25
p(new com.greenlaw110.rythm.play.utils.ActionBridge(false).invokeMethod("save", new Object[] {})); // line: 80
p("\" method=\"post\">\n	        "); //line: 26

{
	com.greenlaw110.rythm.runtime.ITag.ParameterList _pl = null; //line: 27

	_invokeTag("authenticityToken", _pl); //line:27
}p("\n	        <td><input type=\"text\" name=\"contact.name\"></td>\n	        <td><input type=\"text\" name=\"contact.firstname\"></td>\n	        <td><input type=\"text\" name=\"contact.birthdate\"></td>\n	        <td><input type=\"text\" name=\"contact.email\"></td>\n	        <td><input type=\"submit\" value=\"+\"></td>\n	        </form>\n	    </tr>\n	</tbody>\n</table>\n<script type=\"text/javascript\" charset=\""); //line: 37

p(_response_encoding);p("\">\n    // In place edition\n    "); //line: 40
p("$"); //line: 40
p("(\".contact td\").editInPlace("); //line: 40
p("{"); //line: 40
p("\n        bg_over: 'transparent',\n        callback: function(el, n, o) "); //line: 42
p("{"); //line: 42
p("\n            var m = /([a-z]+)-(\\d+)/.exec(el), data = "); //line: 43
p("{"); //line: 43

p('}');
p(";\n            data['contact.id'] = m[2];\n            data['contact.' + m[1]] = n;\n            // Save result\n            "); //line: 48
p("$"); //line: 48
p(".ajax("); //line: 48
p("{"); //line: 48
p("\n                url: '"); //line: 49
p(new com.greenlaw110.rythm.play.utils.ActionBridge(false).invokeMethod("save", new Object[] {})); // line: 80
p("',\n                type: 'POST',\n                data: data,\n                success: function() "); //line: 52
p("{"); //line: 52
p("$"); //line: 52
p("('"); //line: 52
p("#"); //line: 52
p("' + el).html(n)"); //line: 52

p('}');
p(",\n                error: function() "); //line: 53
p("{"); //line: 53
p("$"); //line: 53
p("('"); //line: 53
p("#"); //line: 53
p("' + el).html(o)"); //line: 53

p('}');
p("\n            "); //line: 54

p('}');
p(");\n            return true;\n        "); //line: 57

p('}');
p("\n    "); //line: 58

p('}');
p(")\n    // Drag "); //line: 60
p("&"); //line: 60
p(" Drop\n    var dragIcon = document.createElement('img');\n    dragIcon.src = '"); //line: 62
p("/images/avatar.png"); // line: 80
p("';\n    var action = "); //line: 63

p(jsAction("form", ":id"));p(";\n    var cancel = function cancel(e) "); //line: 64
p("{"); //line: 64
p("e.preventDefault()"); //line: 64

p('}');
p(";\n    "); //line: 66
p("$"); //line: 66
p("('"); //line: 66
p("#"); //line: 66
p("new')\n        .bind('dragover', cancel)\n        .bind('dragenter', cancel)\n        .bind('drop', function(e) "); //line: 69
p("{"); //line: 69
p("\n            document.location = action("); //line: 70
p("{"); //line: 70
p("id: e.originalEvent.dataTransfer.getData('contactId')"); //line: 70

p('}');
p(")\n        "); //line: 71

p('}');
p(")\n    "); //line: 73
p("$"); //line: 73
p("('[draggable]').bind('dragstart', function(e) "); //line: 73
p("{"); //line: 73
p("\n        e.originalEvent.dataTransfer.setData('contactId', "); //line: 74
p("$"); //line: 74
p("(this).attr('contactId'));\n        e.originalEvent.dataTransfer.setDragImage(dragIcon, 0, -10);\n    "); //line: 76

p('}');
p(")\n</script>\n"); //line: 79

return this;
}
}