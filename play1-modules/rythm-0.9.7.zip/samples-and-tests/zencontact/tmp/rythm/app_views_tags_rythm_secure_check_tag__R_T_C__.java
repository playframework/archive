
import controllers.Secure;
import play.templates.JavaExtensions;
import controllers.*;
import models.*;
import java.util.*;
import java.io.*;
public class app_views_tags_rythm_secure_check_tag__R_T_C__ extends com.greenlaw110.rythm.template.TagBase {
@Override public java.lang.String getName() {
	return "secure.check";
}

		protected Object arg=null;
		protected play.mvc.Scope.Flash flash=null;
		protected java.util.List<play.data.validation.Error> errors=null;
		protected java.util.Map<String, java.util.List<play.data.validation.Error>> error=null;
		protected play.mvc.Scope.Session session=null;
		protected play.mvc.Http.Request request=null;
		protected java.lang.String _response_encoding=null;
		protected play.mvc.Scope.Params params=null;
		protected java.lang.String lang=null;
		protected play.i18n.Messages messages=null;
		protected play.Play _play=null;
	@SuppressWarnings("unchecked") public void setRenderArgs(java.util.Map<String, Object> args) {
	if (null != args && args.containsKey("arg")) this.arg=(Object)args.get("arg");
	if (null != args && args.containsKey("flash")) this.flash=(play.mvc.Scope.Flash)args.get("flash");
	if (null != args && args.containsKey("errors")) this.errors=(java.util.List<play.data.validation.Error>)args.get("errors");
	if (null != args && args.containsKey("error")) this.error=(java.util.Map<String, java.util.List<play.data.validation.Error>>)args.get("error");
	if (null != args && args.containsKey("session")) this.session=(play.mvc.Scope.Session)args.get("session");
	if (null != args && args.containsKey("request")) this.request=(play.mvc.Http.Request)args.get("request");
	if (null != args && args.containsKey("_response_encoding")) this._response_encoding=(java.lang.String)args.get("_response_encoding");
	if (null != args && args.containsKey("params")) this.params=(play.mvc.Scope.Params)args.get("params");
	if (null != args && args.containsKey("lang")) this.lang=(java.lang.String)args.get("lang");
	if (null != args && args.containsKey("messages")) this.messages=(play.i18n.Messages)args.get("messages");
	if (null != args && args.containsKey("_play")) this._play=(play.Play)args.get("_play");
	super.setRenderArgs(args);
}
@SuppressWarnings("unchecked") public void setRenderArgs(Object... args) {
	int p = 0, l = args.length;
	if (p < l) { Object v = args[p++]; boolean isString = ("java.lang.String".equals("Object") || "String".equals("Object")); arg = (Object)(isString ? (null == v ? "" : v.toString()) : v); }
}
@SuppressWarnings("unchecked") @Override public void setRenderArg(String name, Object arg) {
	if ("arg".equals(name)) this.arg=(Object)arg;
	if ("flash".equals(name)) this.flash=(play.mvc.Scope.Flash)arg;
	if ("errors".equals(name)) this.errors=(java.util.List<play.data.validation.Error>)arg;
	if ("error".equals(name)) this.error=(java.util.Map<String, java.util.List<play.data.validation.Error>>)arg;
	if ("session".equals(name)) this.session=(play.mvc.Scope.Session)arg;
	if ("request".equals(name)) this.request=(play.mvc.Http.Request)arg;
	if ("_response_encoding".equals(name)) this._response_encoding=(java.lang.String)arg;
	if ("params".equals(name)) this.params=(play.mvc.Scope.Params)arg;
	if ("lang".equals(name)) this.lang=(java.lang.String)arg;
	if ("messages".equals(name)) this.messages=(play.i18n.Messages)arg;
	if ("_play".equals(name)) this._play=(play.Play)arg;
	super.setRenderArg(name, arg);
}
@SuppressWarnings("unchecked") public void setRenderArg(int pos, Object arg) {
int p = 0;
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("Object") || "String".equals("Object")); arg = (Object)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Scope.Flash") || "String".equals("play.mvc.Scope.Flash")); flash = (play.mvc.Scope.Flash)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.util.List<play.data.validation.Error>") || "String".equals("java.util.List<play.data.validation.Error>")); errors = (java.util.List<play.data.validation.Error>)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.util.Map<String, java.util.List<play.data.validation.Error>>") || "String".equals("java.util.Map<String, java.util.List<play.data.validation.Error>>")); error = (java.util.Map<String, java.util.List<play.data.validation.Error>>)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Scope.Session") || "String".equals("play.mvc.Scope.Session")); session = (play.mvc.Scope.Session)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Http.Request") || "String".equals("play.mvc.Http.Request")); request = (play.mvc.Http.Request)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.lang.String") || "String".equals("java.lang.String")); _response_encoding = (java.lang.String)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Scope.Params") || "String".equals("play.mvc.Scope.Params")); params = (play.mvc.Scope.Params)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.lang.String") || "String".equals("java.lang.String")); lang = (java.lang.String)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.i18n.Messages") || "String".equals("play.i18n.Messages")); messages = (play.i18n.Messages)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.Play") || "String".equals("play.Play")); _play = (play.Play)(isString ? (null == v ? "" : v.toString()) : v); }
	if(0 == pos) setRenderArg("arg", arg);
}
@Override public com.greenlaw110.rythm.utils.TextBuilder build(){
	out().ensureCapacity(234);p(""); //line: 1
p("\n"); //line: 3
if (session.get("username") != null) {p("\n    Object o = Secure.Security.invoke(\"check\", arg);\n    if (((Boolean)o).booleanValue()) "); //line: 5
p("{"); //line: 5
p("\n        "); //line: 6

p(_body);p("\n    "); //line: 7

p('}');
p("\n"); //line: 8
}p("\n"); //line: 9
p(""); //line: 9

return this;
}
}