
import play.templates.JavaExtensions;
import controllers.*;
import models.*;
import java.util.*;
import java.io.*;
public class app_views_tags_rythm_welcome_html__R_T_C__ extends com.greenlaw110.rythm.template.TagBase {
@Override public java.lang.String getName() {
	return "welcome";
}

		protected play.mvc.Scope.Flash flash=null;
		protected java.util.List<play.data.validation.Error> errors=null;
		protected java.util.Map<String, java.util.List<play.data.validation.Error>> error=null;
		protected play.mvc.Scope.Session session=null;
		protected play.mvc.Http.Request request=null;
		protected java.lang.String _response_encoding=null;
		protected play.mvc.Scope.Params params=null;
		protected java.lang.String lang=null;
		protected play.i18n.Messages messages=null;
		protected play.Play _play=null;
	@SuppressWarnings("unchecked") public void setRenderArgs(java.util.Map<String, Object> args) {
	if (null != args && args.containsKey("flash")) this.flash=(play.mvc.Scope.Flash)args.get("flash");
	if (null != args && args.containsKey("errors")) this.errors=(java.util.List<play.data.validation.Error>)args.get("errors");
	if (null != args && args.containsKey("error")) this.error=(java.util.Map<String, java.util.List<play.data.validation.Error>>)args.get("error");
	if (null != args && args.containsKey("session")) this.session=(play.mvc.Scope.Session)args.get("session");
	if (null != args && args.containsKey("request")) this.request=(play.mvc.Http.Request)args.get("request");
	if (null != args && args.containsKey("_response_encoding")) this._response_encoding=(java.lang.String)args.get("_response_encoding");
	if (null != args && args.containsKey("params")) this.params=(play.mvc.Scope.Params)args.get("params");
	if (null != args && args.containsKey("lang")) this.lang=(java.lang.String)args.get("lang");
	if (null != args && args.containsKey("messages")) this.messages=(play.i18n.Messages)args.get("messages");
	if (null != args && args.containsKey("_play")) this._play=(play.Play)args.get("_play");
	super.setRenderArgs(args);
}
@SuppressWarnings("unchecked") @Override public void setRenderArg(String name, Object arg) {
	if ("flash".equals(name)) this.flash=(play.mvc.Scope.Flash)arg;
	if ("errors".equals(name)) this.errors=(java.util.List<play.data.validation.Error>)arg;
	if ("error".equals(name)) this.error=(java.util.Map<String, java.util.List<play.data.validation.Error>>)arg;
	if ("session".equals(name)) this.session=(play.mvc.Scope.Session)arg;
	if ("request".equals(name)) this.request=(play.mvc.Http.Request)arg;
	if ("_response_encoding".equals(name)) this._response_encoding=(java.lang.String)arg;
	if ("params".equals(name)) this.params=(play.mvc.Scope.Params)arg;
	if ("lang".equals(name)) this.lang=(java.lang.String)arg;
	if ("messages".equals(name)) this.messages=(play.i18n.Messages)arg;
	if ("_play".equals(name)) this._play=(play.Play)arg;
	super.setRenderArg(name, arg);
}
@SuppressWarnings("unchecked") public void setRenderArg(int pos, Object arg) {
int p = 0;
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Scope.Flash") || "String".equals("play.mvc.Scope.Flash")); flash = (play.mvc.Scope.Flash)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.util.List<play.data.validation.Error>") || "String".equals("java.util.List<play.data.validation.Error>")); errors = (java.util.List<play.data.validation.Error>)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.util.Map<String, java.util.List<play.data.validation.Error>>") || "String".equals("java.util.Map<String, java.util.List<play.data.validation.Error>>")); error = (java.util.Map<String, java.util.List<play.data.validation.Error>>)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Scope.Session") || "String".equals("play.mvc.Scope.Session")); session = (play.mvc.Scope.Session)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Http.Request") || "String".equals("play.mvc.Http.Request")); request = (play.mvc.Http.Request)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.lang.String") || "String".equals("java.lang.String")); _response_encoding = (java.lang.String)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Scope.Params") || "String".equals("play.mvc.Scope.Params")); params = (play.mvc.Scope.Params)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.lang.String") || "String".equals("java.lang.String")); lang = (java.lang.String)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.i18n.Messages") || "String".equals("play.i18n.Messages")); messages = (play.i18n.Messages)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.Play") || "String".equals("play.Play")); _play = (play.Play)(isString ? (null == v ? "" : v.toString()) : v); }
	if(0 == pos) setRenderArg("arg", arg);
}
@Override public com.greenlaw110.rythm.utils.TextBuilder build(){
	out().ensureCapacity(5989);p(""); //line: 1

_setRenderProperty("title","Your application is ready !");p("\n"); //line: 3
if ("DEV".equals(_play.mode.toString())) {p("\n"); //line: 5
p("@"); //line: 5
p("section(\"moreStyles\") "); //line: 5
p("{"); //line: 5
p("\n	<link rel=\"stylesheet\" href=\"/public/playmanual/manual.css\" type=\"text/css\" media=\"screen\" charset=\""); //line: 6

p(_response_encoding);p("\">\n	<link rel=\"stylesheet\" href=\"/public/playmanual/wiki.css\" type=\"text/css\" media=\"screen\" charset=\""); //line: 7

p(_response_encoding);p("\">\n"); //line: 8

p('}');
p("\n<div class=\"wrapper\">\n	<div id=\"docSidebar\">\n		\n		<div id=\"logo\">\n			<img src=\"/public/playmanual/logo.png\">\n			<h2 id=\"version\">Play "); //line: 16

p(_play.version);p("</h2>\n		</div>\n        <h2>Browse</h2>\n        <ul>\n            <li id=\"gotoc\"><a href=\"/"); //line: 21
p("@documentation/home\">Local documentation</a></li>\n            <li id=\"gotoc\"><a href=\"/"); //line: 22
p("@api/index.html\">Browse Java API</a></li>\n        </ul>\n        <h2>Contents</h2>\n        <div id=\"toc\"></div>\n"); //line: 28
p("\n        <h2>Search</h2>\n        <p>Get help with google</p>\n        <div id=\"searchBox\"><form action=\"http://www.google.com/cse\" id=\"cse-search-box\"><div><input type=\"hidden\" name=\"cx\" value=\"002614023023983855063:jn1mu_7bof0\" /><input type=\"hidden\" name=\"ie\" value=\"UTF-8\" /><input type=\"text\" name=\"q\" size=\"28\" style=\"font-size:14px\"/></div></form><script type=\"text/javascript\" src=\"http://www.google.com/coop/cse/brand?form=cse-search-box"); //line: 45
p("&"); //line: 45
p("lang=en\"></script></div>\n    </div>\n	<div id=\"pageContent\">\n		<div class=\"wikistyle\">\n            <h1>Your new application is ready!</h1>\n            <p>\n                Congratulation, you've just created a new play application. This page will help you in the few next steps.\n            </p>\n            <h2><a name=\"why\">Why do you see this page?</a></h2>\n            <p>\n                The <strong>conf/routes</strong> file defines a route that tell play to invoke the <strong>Application.index</strong> action\n                when a browser requests the <strong>/</strong> URI using the <strong>GET</strong> method:\n            </p>\n            <pre><code>"); //line: 61
p("#"); //line: 61
p(" Application home page\nGET     /         Application.index</code></pre>\n            <p>\n                So play has invoked the <strong>controllers"); //line: 64
p("&"); //line: 64
p("#"); //line: 64
p("46;Application"); //line: 64
p("&"); //line: 64
p("#"); //line: 64
p("46;index()</strong> method:\n            </p>\n            <pre><code>public static void index() "); //line: 66
p("{"); //line: 66
p("\n    render();\n"); //line: 68

p('}');
p("</code></pre>\n            <p>\n                Using the <strong>render()</strong> call, this action asks play to display a template. By convention play has\n                displayed the <strong>app/views/Application/index.html</strong> template:\n            </p>\n            <pre><code>"); //line: 73
p("&"); //line: 73
p("#"); //line: 73
p("35;"); //line: 73
p("{"); //line: 73
p("extends 'main.html' /"); //line: 73

p('}');
p("\n"); //line: 74
p("&"); //line: 74
p("#"); //line: 74
p("35;"); //line: 74
p("{"); //line: 74
p("set title:'Home' /"); //line: 74

p('}');
p("\n"); //line: 76
p("&"); //line: 76
p("#"); //line: 76
p("35;"); //line: 76
p("{"); //line: 76
p("welcome /"); //line: 76

p('}');
p("</code></pre>\n            <p>\n                This template extends the <strong>app/views/main.html</strong>, and uses the <strong>"); //line: 78
p("&"); //line: 78
p("#"); //line: 78
p("35;"); //line: 78
p("{"); //line: 78
p("welcome /"); //line: 78

p('}');
p("</strong> tag to display this\n                welcome page.\n            </p>\n            <h2><a name=\"ide\">Need to set up a Java IDE?</a></h2>\n            <p>\n                You can start right now to hack your application using any text editor. Any changes will be automatically realoaded at the\n                next page refresh, including modifications made to Java sources files.\n            </p>\n            <p>\n                If you want to set up your application in <strong>Eclipse</strong>, <strong>Netbeans</strong> or any other Java IDE, check\n                the <a href=\"/"); //line: 88
p("@documentation/ide\">Setting up your preferred IDE</a> page.\n            </p>\n            <h2><a name=\"db\">Need to connect to a database?</a></h2>\n            <p>\n                You can quickly set up a developement database (either in memory or written to the filesystem), by adding one of these\n                lines to the <strong>conf/application.conf</strong> file:\n            </p>\n<pre><code>"); //line: 95
p("#"); //line: 95
p(" For a transient in memory database (H2 in memory)\ndb=mem\n"); //line: 98
p("#"); //line: 98
p(" for a simple file written database (H2 file stored)\ndb=fs</code></pre>\n            <p>\n                If you want to connect to an existing <strong>MySQL5 server</strong>, use:\n            </p>\n<pre><code>db=mysql:user:pwd"); //line: 103
p("@database_name</code></pre>\n            <p>\n                If you need to connect to another JDBC compliant database, first add the corresponding driver library to the\n                <strong>lib/</strong> directory of your application, and add these lines to the <strong>conf/application.conf</strong> file:\n            </p>\n            <pre><code>db.url=jdbc:postgresql:database_name\ndb.driver=org.postgresql.Driver\ndb.user=root\ndb.pass=secret</code></pre>      \n            <h2><a name=\"doc\">Need more help?</a></h2>\n            <p>\n                When your application run in <strong>DEV</strong> mode, you can access directly the current documentation at the\n                <a href=\"/"); //line: 115
p("@documentation\">/"); //line: 115
p("@documentation</a> URL or go to <a href=\"http://www.playframework.org\">http://www.playframework.org</a>.\n            </p>\n            <p>\n                The <a href=\"http://groups.google.com/group/play-framework\">Play Google Group</a> is where Play users come to seek help, announce projects, and discuss. \n                If you don't have any google account, you can still join the mailing list sending an email to\n                <br/><strong>play-framework+subscribe"); //line: 120
p("@googlegroups.com</strong>.\n            </p>\n        </div>\n    </div>\n			\n		</div>\n	</div>\n</div>\n	\n<script type=\"text/javascript\" src=\"/public/playmanual/jquery-1.3.2.min.js\"></script>\n<script type=\"text/javascript\" src=\"/public/playmanual/navigation.js\"></script>\n"); //line: 134
}else {p("\n    <h1>Your application is ready!</h1>\n"); //line: 136
}p("\n"); //line: 137
p(""); //line: 137

return this;
}
}