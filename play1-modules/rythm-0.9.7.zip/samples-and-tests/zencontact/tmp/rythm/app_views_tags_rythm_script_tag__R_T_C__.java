
import play.Play;
import play.mvc.Router;
import play.templates.JavaExtensions;
import controllers.*;
import models.*;
import java.util.*;
import java.io.*;
public class app_views_tags_rythm_script_tag__R_T_C__ extends com.greenlaw110.rythm.template.TagBase {
@Override public java.lang.String getName() {
	return "script";
}

		protected String src=null;
		protected String id=null;
		protected String charset=null;
		protected play.mvc.Scope.Flash flash=null;
		protected java.util.List<play.data.validation.Error> errors=null;
		protected java.util.Map<String, java.util.List<play.data.validation.Error>> error=null;
		protected play.mvc.Scope.Session session=null;
		protected play.mvc.Http.Request request=null;
		protected java.lang.String _response_encoding=null;
		protected play.mvc.Scope.Params params=null;
		protected java.lang.String lang=null;
		protected play.i18n.Messages messages=null;
		protected play.Play _play=null;
	@SuppressWarnings("unchecked") public void setRenderArgs(java.util.Map<String, Object> args) {
	if (null != args && args.containsKey("src")) this.src=(String)args.get("src");
	if (null != args && args.containsKey("id")) this.id=(String)args.get("id");
	if (null != args && args.containsKey("charset")) this.charset=(String)args.get("charset");
	if (null != args && args.containsKey("flash")) this.flash=(play.mvc.Scope.Flash)args.get("flash");
	if (null != args && args.containsKey("errors")) this.errors=(java.util.List<play.data.validation.Error>)args.get("errors");
	if (null != args && args.containsKey("error")) this.error=(java.util.Map<String, java.util.List<play.data.validation.Error>>)args.get("error");
	if (null != args && args.containsKey("session")) this.session=(play.mvc.Scope.Session)args.get("session");
	if (null != args && args.containsKey("request")) this.request=(play.mvc.Http.Request)args.get("request");
	if (null != args && args.containsKey("_response_encoding")) this._response_encoding=(java.lang.String)args.get("_response_encoding");
	if (null != args && args.containsKey("params")) this.params=(play.mvc.Scope.Params)args.get("params");
	if (null != args && args.containsKey("lang")) this.lang=(java.lang.String)args.get("lang");
	if (null != args && args.containsKey("messages")) this.messages=(play.i18n.Messages)args.get("messages");
	if (null != args && args.containsKey("_play")) this._play=(play.Play)args.get("_play");
	super.setRenderArgs(args);
}
@SuppressWarnings("unchecked") public void setRenderArgs(Object... args) {
	int p = 0, l = args.length;
	if (p < l) { Object v = args[p++]; boolean isString = ("java.lang.String".equals("String") || "String".equals("String")); src = (String)(isString ? (null == v ? "" : v.toString()) : v); }
	if (p < l) { Object v = args[p++]; boolean isString = ("java.lang.String".equals("String") || "String".equals("String")); id = (String)(isString ? (null == v ? "" : v.toString()) : v); }
	if (p < l) { Object v = args[p++]; boolean isString = ("java.lang.String".equals("String") || "String".equals("String")); charset = (String)(isString ? (null == v ? "" : v.toString()) : v); }
}
@SuppressWarnings("unchecked") @Override public void setRenderArg(String name, Object arg) {
	if ("src".equals(name)) this.src=(String)arg;
	if ("id".equals(name)) this.id=(String)arg;
	if ("charset".equals(name)) this.charset=(String)arg;
	if ("flash".equals(name)) this.flash=(play.mvc.Scope.Flash)arg;
	if ("errors".equals(name)) this.errors=(java.util.List<play.data.validation.Error>)arg;
	if ("error".equals(name)) this.error=(java.util.Map<String, java.util.List<play.data.validation.Error>>)arg;
	if ("session".equals(name)) this.session=(play.mvc.Scope.Session)arg;
	if ("request".equals(name)) this.request=(play.mvc.Http.Request)arg;
	if ("_response_encoding".equals(name)) this._response_encoding=(java.lang.String)arg;
	if ("params".equals(name)) this.params=(play.mvc.Scope.Params)arg;
	if ("lang".equals(name)) this.lang=(java.lang.String)arg;
	if ("messages".equals(name)) this.messages=(play.i18n.Messages)arg;
	if ("_play".equals(name)) this._play=(play.Play)arg;
	super.setRenderArg(name, arg);
}
@SuppressWarnings("unchecked") public void setRenderArg(int pos, Object arg) {
int p = 0;
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("String") || "String".equals("String")); src = (String)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("String") || "String".equals("String")); id = (String)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("String") || "String".equals("String")); charset = (String)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Scope.Flash") || "String".equals("play.mvc.Scope.Flash")); flash = (play.mvc.Scope.Flash)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.util.List<play.data.validation.Error>") || "String".equals("java.util.List<play.data.validation.Error>")); errors = (java.util.List<play.data.validation.Error>)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.util.Map<String, java.util.List<play.data.validation.Error>>") || "String".equals("java.util.Map<String, java.util.List<play.data.validation.Error>>")); error = (java.util.Map<String, java.util.List<play.data.validation.Error>>)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Scope.Session") || "String".equals("play.mvc.Scope.Session")); session = (play.mvc.Scope.Session)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Http.Request") || "String".equals("play.mvc.Http.Request")); request = (play.mvc.Http.Request)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.lang.String") || "String".equals("java.lang.String")); _response_encoding = (java.lang.String)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.mvc.Scope.Params") || "String".equals("play.mvc.Scope.Params")); params = (play.mvc.Scope.Params)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("java.lang.String") || "String".equals("java.lang.String")); lang = (java.lang.String)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.i18n.Messages") || "String".equals("play.i18n.Messages")); messages = (play.i18n.Messages)(isString ? (null == v ? "" : v.toString()) : v); }
if (p++ == pos) { Object v = arg; boolean isString = ("java.lang.String".equals("play.Play") || "String".equals("play.Play")); _play = (play.Play)(isString ? (null == v ? "" : v.toString()) : v); }
	if(0 == pos) setRenderArg("arg", arg);
}
@Override public com.greenlaw110.rythm.utils.TextBuilder build(){
	out().ensureCapacity(1726);p(""); //line: 1
p("\n"); //line: 13
p("\n"); //line: 30
p("\n"); //line: 32
 //line: 33
    if (null == src) throw new play.exceptions.TagInternalException("src attribute cannot be empty for script tag"); //line: 34
    src = "/public/javascripts/" + src; //line: 35
    String _abs = null; //line: 36
    try { //line: 37
        _abs = Router.reverseWithCheck(src, Play.getVirtualFile(src), false); //line: 38
    } catch (Exception e) { //line: 39
        throw new play.exceptions.TagInternalException("File not found: " + src); //line: 40
    } //line: 41
;p("\n<script type=\"text/javascript\" language=\"javascript\""); //line: 42
if (null != id) {p("id=\""); //line: 42

p(id);p("\""); //line: 42
}p(" "); //line: 42
if (null != charset) {p("charset=\""); //line: 42

p(charset);p("\""); //line: 42
}p(" src=\""); //line: 42

p(_abs);p("\"></script>\n"); //line: 43
p(""); //line: 43

return this;
}
}