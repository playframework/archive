package controllers;

import play.mvc.Controller;

// TODO: Auto-generated Javadoc
/**
 * The Class ElasticSearchAdmin.
 */
public class ElasticSearchAdmin extends Controller {
	
	/**
	 * Index.
	 */
	public static void index() {
		render();
	}

}
