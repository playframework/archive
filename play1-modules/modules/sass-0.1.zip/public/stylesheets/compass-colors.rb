module Compass
  module Colors
  end
end

require File.join(File.dirname(__FILE__), 'compass/colors', 'hsl')
require File.join(File.dirname(__FILE__), 'compass/colors', 'sass_extensions')
