package springtester;

import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
public class HeightCalculator {
    @Resource private Ruler ruler;

    public int calculate() {
        // some code that calculates the person's height
        return 200;
    }
}
