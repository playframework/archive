package cn.bran.japid.util;

public class JapidFlags {

	public static boolean verbose = true;

}
