package springtester;

import org.springframework.stereotype.Component;

@Component
public class Ruler {
    // Just a dummy class that is used to inject into the HeightCalculator class.
}
