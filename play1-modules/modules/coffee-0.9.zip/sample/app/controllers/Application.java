package controllers;

import play.*;
import play.mvc.*;

import java.util.*;

import models.*;

public class Application extends Controller {

    public static void index() {
        render();
    }

    public static void inline() {
        render();
    }

    public static void include() {
        render();
    }

    public static void includeError() {
        render();
    }

    public static void inlineError() {
        render();
    }
}
