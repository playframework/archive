package models;

import play.modules.neo4j.model.Neo4jModel;

public class Address extends Neo4jModel {

    public String title;

}
