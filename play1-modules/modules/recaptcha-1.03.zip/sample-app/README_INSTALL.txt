How to run it ?

# install the recaptcha module
play install recaptcha

# launch the app
play run sample-app

