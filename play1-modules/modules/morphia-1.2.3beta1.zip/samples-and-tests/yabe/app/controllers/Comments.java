package controllers;

import play.mvc.With;

//@Check("admin")
public class Comments {    
}