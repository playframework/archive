package controllers;

public class Users extends CRUD {

}
