package japidviews.more.MyController;

import java.util.*;
import java.io.*;
import cn.bran.japid.tags.Each;
import static play.templates.JavaExtensions.*;
import static cn.bran.play.JapidPlayAdapter.*;
import static play.data.validation.Validation.*;
import static cn.bran.play.WebUtils.*;
import japidviews._layouts.*;
import static japidviews._javatags.JapidWebUtil.*;
import play.data.validation.Validation;
import play.mvc.Scope.*;
import models.*;
import play.data.validation.Error;
import japidviews._tags.*;
import controllers.*;
import play.mvc.Http.*;
import japidviews._javatags.*;
//
// NOTE: This file was generated from: japidviews/more/MyController/myLayout.html
// Change to this file will be lost next time the template file is compiled.
//

@cn.bran.play.NoEnhance
public abstract class myLayout extends cn.bran.japid.template.JapidTemplateBase {
	public static final String sourceTemplate = "japidviews/more/MyController/myLayout.html";
	{
		headers.put("Content-Type", "text/html; charset=utf-8");
	}

	public myLayout() {
		super(null);
	}

	public myLayout(StringBuilder out) {
		super(out);
	}

	@Override
	public void layout() {
		// - add implicit variables 

		final Request request = Request.current();
		assert request != null;

		final Response response = Response.current();
		assert response != null;

		final Flash flash = Flash.current();
		assert flash != null;

		final Session session = Session.current();
		assert session != null;

		final RenderArgs renderArgs = RenderArgs.current();
		assert renderArgs != null;

		final Params params = Params.current();
		assert params != null;

		final Validation validation = Validation.current();
		assert validation != null;

		final cn.bran.play.FieldErrors errors = new cn.bran.play.FieldErrors(
				validation);
		assert errors != null;

		final play.Play _play = new play.Play();
		assert _play != null;

		// - end of implicit variables 

		p("<p>");// line 1
		title();// line 1
		p("</p>\n" +
				"<p>");// line 1
		side();// line 2
		p("</p>\n" +
				"<p>\n");// line 2
		doLayout();// line 4
		p("</p>\n");// line 4
	}

	protected void title() {
	};

	protected void side() {
	};

	protected abstract void doLayout();
}
