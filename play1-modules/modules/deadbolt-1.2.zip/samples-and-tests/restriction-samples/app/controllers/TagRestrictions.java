package controllers;

import play.mvc.Controller;

/**
 * @author Steve Chaloner (steve@objectify.be).
 */
public class TagRestrictions extends Controller
{
    public static void index()
    {
        render();
    }
}
