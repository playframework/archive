package springtester;

import org.springframework.stereotype.Component;

@Component
public class AgeCalculator {

    public int calculate(String birthDate) {
        // some code that figures out the age of the person
        return 1;
    }
}
