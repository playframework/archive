package springtester;

import org.springframework.stereotype.Component;

@Component
public class HeightCalculator {

    public int calculate() {
        // some code that calculates the person's height
        return 200;
    }
}
