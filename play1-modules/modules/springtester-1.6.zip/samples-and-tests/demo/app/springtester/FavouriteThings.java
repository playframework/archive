package springtester;

import org.springframework.stereotype.Component;

@Component
public class FavouriteThings {

    public String sport() {
        return "football";
    }

    public int number() {
        return 10;
    }
}
