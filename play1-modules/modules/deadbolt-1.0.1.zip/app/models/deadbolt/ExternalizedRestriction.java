package models.deadbolt;

import java.util.List;

/**
 * @author Steve Chaloner (steve@objectify.be).
 */
public interface ExternalizedRestriction
{
    List<String> getRoleNames();
}
