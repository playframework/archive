package controllers;

import play.mvc.Controller;

public class Unrestricted extends Controller
{
    public static void index()
    {
        render();
    }
}