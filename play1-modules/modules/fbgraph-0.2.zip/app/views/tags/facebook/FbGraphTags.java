package views.tags.facebook;

import groovy.lang.Closure;
import java.io.PrintWriter;
import java.util.Map;
import play.modules.facebook.FbGraph;
import play.templates.FastTags;
import play.templates.GroovyTemplate.ExecutableTemplate;

/**
 *
 * @author Eric Jacob
 */
@FastTags.Namespace("fbg")
public class FbGraphTags extends FastTags {

    public static void _script(Map<?, ?> args, Closure body, PrintWriter out, ExecutableTemplate template, int fromLine) {
        out.println("<div id='fb-root'></div>");
        out.println("<script src='http://connect.facebook.net/en_US/all.js'></script>");
        out.println("<script>");
        out.println("FB.init({appId: '" + FbGraph.getAppId() + "', status: true, cookie: true, xfbml: true});");
        out.println("</script>");
    }
}
