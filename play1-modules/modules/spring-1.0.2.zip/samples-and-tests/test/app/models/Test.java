package models;

public class Test {

    public String name = "Hello world!";

}

