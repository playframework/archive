package play.modules.search.store;

public class ManagedIndex {
    public String name;
    public boolean optimized;
    public long documentCount;
    public long jpaCount;
}
