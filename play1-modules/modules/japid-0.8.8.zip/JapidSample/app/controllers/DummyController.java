package controllers;

public class DummyController {

}
