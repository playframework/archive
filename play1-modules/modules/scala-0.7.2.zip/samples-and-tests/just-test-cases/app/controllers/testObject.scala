package controllers
 
object Apple1 {
  var name = "BOO"
}

