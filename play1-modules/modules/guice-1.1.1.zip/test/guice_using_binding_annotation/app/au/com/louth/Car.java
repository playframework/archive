package au.com.louth;

public interface Car {

	public String drive();
	
}
