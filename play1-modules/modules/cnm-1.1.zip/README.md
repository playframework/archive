# Play Content Negotiation Module

This module is intended to be used together with the Play! framework. It lets you easily add new
supported content types for clients to consume.

For this clients need to set their Accept header to whatever supported content type they want. See
http://www.playframework.org/modules/cnm for a more complete documentation.

