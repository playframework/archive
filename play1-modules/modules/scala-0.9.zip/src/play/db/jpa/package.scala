import play.data.validation._
import javax.persistence

package play { 
    
    package db {

        package object jpa{

            type Model = play.db.jpa.ScalaModel
        
        }
      
    }
    
}
