package models.japidsample;

import java.util.Date;

public class Author2 extends Author{
	public String who = "author2";
}
