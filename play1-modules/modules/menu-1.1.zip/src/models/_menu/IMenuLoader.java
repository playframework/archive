package models._menu;

public interface IMenuLoader {
    void loadMenu();
}
