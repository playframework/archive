package models
object AAA { def name = 88 }
