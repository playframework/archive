# Stax commands
# ~~~~

import sys

# ~~~~~~~~~~~~~~~~~~~~~~ New
if play_command == 'new':
	appconf = open(os.path.join(application_path, 'conf/application.conf'), 'a')
	appconf.write("\n")
	appconf.write("# Stax Database configuration\n")
	appconf.write("# ~~~~~\n")
	appconf.write("# to deploy on stax: uncomment, replace yourProject, yourDBName, login and password by the correct values\n")
	appconf.write("# before generating the war\n")
	appconf.write("# db.url=jdbc:stax://yourDBName\n")
	appconf.write("# db.driver=com.staxnet.jdbc.Driver\n")
	appconf.write("# db.user=dblogin\n")
	appconf.write("# db.pass=dbpassword\n\n")
	appconf.write("# jpa.dialect=org.hibernate.dialect.MySQLDialect\n")
	webinf = os.path.join(application_path, 'war', 'WEB-INF')
	if not os.path.exists(webinf):
		os.makedirs(webinf)
	f = open(os.path.join(webinf, 'stax-application.xml'), 'w')
	f.write("<?xml version=\"1.0\"?>\n")
	f.write("        <stax-web-app xmlns=\"http://www.stax.net/xml/webapp/1\">\n")
	f.write("</stax-web-app>")
