package controllers

import play._
import play.mvc._

object Application extends ScalateController {
    
    def index = renderScalate()
    
}
