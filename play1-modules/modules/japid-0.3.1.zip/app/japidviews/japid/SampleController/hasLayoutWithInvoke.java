package japidviews.japid.SampleController;
import java.util.*;
import java.io.*;
import cn.bran.japid.tags.Each;
import japidviews._layouts.*;
import japidviews._tags.*;
import static cn.bran.play.JapidPlayAdapter.*;
// NOTE: This file was generated from: japidviews/japid/SampleController/hasLayoutWithInvoke.html
// Change to this file will be lost next time the template file is compiled.
@cn.bran.play.NoEnhance
public class hasLayoutWithInvoke extends lcomposite{
	public static final String sourceTemplate = "japidviews/japid/SampleController/hasLayoutWithInvoke.html";
static private final String static_0 = ""
;
static private final String static_1 = "\n" + 
"<p>This file does not do invoke, but the layout does</p>\n" + 
"";
	public hasLayoutWithInvoke() {
		super(null);
	}
	public hasLayoutWithInvoke(StringBuilder out) {
		super(out);
	}
	public cn.bran.japid.template.RenderResult render() {
		long t = -1;
		super.layout();
		return new cn.bran.japid.template.RenderResultPartial(this.headers, getOut(), t, actionRunners);
	}
	@Override protected void doLayout() {
p(static_0);// line 1
p(static_1);// line 1

	}
}
