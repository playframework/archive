package controllers;

import models.PersonLongAutoIDExtendedAbstract;
 
@CRUD.For(PersonLongAutoIDExtendedAbstract.class)
public class PersonLongAutoIDExtendedAbstracts extends controllers.CRUD {    

}
