package controllers;

import models.Employee;
import models.Fourword;
 
@CRUD.For(Fourword.class)
public class Fourwords extends controllers.CRUD {    

}
