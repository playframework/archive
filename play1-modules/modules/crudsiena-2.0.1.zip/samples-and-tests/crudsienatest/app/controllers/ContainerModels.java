package controllers;

import models.ContainerModel;
 
@CRUD.For(ContainerModel.class)
public class ContainerModels extends controllers.CRUD {    

}
