package play.modules.ebean;

import javax.persistence.MappedSuperclass;

import com.avaje.ebean.EbeanServer;

@MappedSuperclass
public class EbeanSupport
{

  protected static EbeanServer ebean()
  {
    return EbeanContext.server();
  }

  public void refresh()
  {
    ebean().refresh(this);
  }

  //@SuppressWarnings("unchecked")
  final public void /*<T extends EbeanModel> T */save()
  {
    ebean().save(this);
    // return (T) this;
  }

  final public void delete()
  {
    ebean().delete(this);
  }

  protected void afterLoad()
  {
  }

  protected void onSave()
  {
  }

}