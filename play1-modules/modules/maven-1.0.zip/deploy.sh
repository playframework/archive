#!/bin/sh
rm -Rf $PLAY_HOME/modules/maven*
mkdir $PLAY_HOME/modules/maven-head
cp -Rf * $PLAY_HOME/modules/maven-head
