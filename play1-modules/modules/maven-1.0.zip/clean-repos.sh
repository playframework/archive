#!/bin/sh
rm -Rf ~/.m2/repository/org/play
