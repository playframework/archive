PlayRythm v1.0

Gelin Luo (greenlaw110@gmail.com)

PlayRythm is a Play!Framework plugin. It provides a high performance static typed Java template engine which is easy to adapt by Groovy template users. 

PlayRythm is built upon the Rythm template engine: https://github.com/greenlaw110/rythm

Read more on https://github.com/greenlaw110/play-rythm/blob/master/documentation/manual/user_guide.textile

License:

PlayRythm is distributed under Apache License v2.0 (http://www.apache.org/licenses/LICENSE-2.0.html)