package press;

import play.Logger;

public class PressLogger {
    public static void trace(String message, Object... args) {
        Logger.info("Press: " + message, args);
    }
}
