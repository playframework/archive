package controllers

import play._
import play.mvc._

object Application extends Controller {

    def index = <h1>Welcome to the akka play module by <a href="http://twitter.com/dustinwhitney">@dustinwhitney</a></h1>
    
}