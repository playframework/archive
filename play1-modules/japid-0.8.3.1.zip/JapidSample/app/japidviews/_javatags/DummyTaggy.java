package japidviews._javatags;

public class DummyTaggy {

}
