package play.modules.jpagen;

public enum ModeEnum {
	MYSQL,ORACLE;
}
