package play.modules.jpagen;

import java.util.ArrayList;
import java.util.List;

public class IdClass {

	public String packageName;
	public String className;
	
	public List<Column> keys = new ArrayList<Column>();
	
}
