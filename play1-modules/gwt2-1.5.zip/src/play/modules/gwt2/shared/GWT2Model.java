package play.modules.gwt2.shared;

/**
 * Model class to use with GWT2Model
 * @author Vincent Buzzano
 * 
 * this Model class is not yet use .. it is experimental
 *
 */
public class GWT2Model { // implements Model {

	public void _delete() {
        throw new UnsupportedOperationException("Please annotate your JPA model with @javax.persistence.Entity annotation.");
	}

	public Object _key() {
        throw new UnsupportedOperationException("Please annotate your JPA model with @javax.persistence.Entity annotation.");		
	}

	public void _save() {
        throw new UnsupportedOperationException("Please annotate your JPA model with @javax.persistence.Entity annotation.");		
	}
}
