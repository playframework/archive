package com.carbonfive.jdbc;

public enum DatabaseType
{
    MYSQL, POSTGRESQL, SQL_SERVER, HSQL, H2, DB2, ORACLE, UNKNOWN
}
