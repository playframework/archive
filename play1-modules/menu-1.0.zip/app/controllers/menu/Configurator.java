package controllers.menu;

import play.mvc.Controller;

public class Configurator extends Controller {
    public static void index() {
        render();
    }
}
