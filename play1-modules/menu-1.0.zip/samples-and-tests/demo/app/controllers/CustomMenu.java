package controllers;

import play.mvc.Controller;
import play.mvc.With;

@With({_Menus.class})
public class CustomMenu extends DefaultMenu {

}
