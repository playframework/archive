package cn.bran.misc;

public class ComplexClass implements MyInterface {
	int c = 0;
	public void doSomething(int i) {
		c += i;
	}

}
