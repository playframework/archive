package controllers;

/**
 * @author huljas
 */
public enum MessagesAction {
    REMOVE,
    UNIGNORE, IGNORE
}
