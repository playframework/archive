About the Eclipse JDT Core Lib

The plain Japid depends on the JDT core lib jar, named like .org.eclipse.jdt.core_3.6.1.v_A68_R36x.jar.

The jar name has been deliberately prefixed with a "." so that the Play tool won't include it in the module package. 

This has been done for reducing the module size. 

When using as plain Japid template engine, make sure you have this jar in the lib.plain directory or please download the jar from:

https://github.com/branaway/Japid/tree/master/lib.plain
