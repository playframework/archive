package models;

public class SearchParams {
    public String keywords;
    public String mode;
	public SearchParams(String keywords, String mode) {
		super();
		this.keywords = keywords;
		this.mode = mode;
	}
    
}