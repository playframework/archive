package annotations;

public @interface NoJsonExport {

}
