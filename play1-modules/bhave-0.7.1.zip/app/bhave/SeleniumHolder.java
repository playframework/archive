package bhave;

public class SeleniumHolder {
	
	public static org.openqa.selenium.server.SeleniumServer server;

}
