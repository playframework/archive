package controllers;

public class Books extends CRUD {

    
}
