package controllers;


import models.Publisher;

@CRUD.For(Publisher.class)
public class Libraries extends CRUD {

    
}
