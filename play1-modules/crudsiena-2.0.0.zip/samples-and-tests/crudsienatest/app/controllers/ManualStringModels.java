package controllers;

import models.ManualStringModel;
 
@CRUD.For(ManualStringModel.class)
public class ManualStringModels extends controllers.CRUD {    

}
