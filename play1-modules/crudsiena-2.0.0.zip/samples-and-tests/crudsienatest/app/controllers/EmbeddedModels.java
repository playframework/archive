package controllers;

import models.EmbeddedModel;
 
@CRUD.For(EmbeddedModel.class)
public class EmbeddedModels extends controllers.CRUD {    

}
