package controllers;

import models.UUIDModel;
 
@CRUD.For(UUIDModel.class)
public class UUIDModels extends controllers.CRUD {    

}
