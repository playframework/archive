package controllers;


public class Comments extends CRUD {

}
