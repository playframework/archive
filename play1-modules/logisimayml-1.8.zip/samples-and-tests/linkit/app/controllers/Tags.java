package controllers;


public class Tags extends CRUD {

}
